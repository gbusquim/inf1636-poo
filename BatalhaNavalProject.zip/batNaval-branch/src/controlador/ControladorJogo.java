package controlador;

import regras.*;

import gui.FRFaseAtaques;

public class ControladorJogo {
	private Jogador jogador1,jogador2;
	private Jogador jogadorAtual,oponente;
	private ControladorTelas controladorTelas;
	private boolean transicaoTurno;
	private boolean jogoEncerrado;
	
	public ControladorJogo(ControladorTelas controladorTelas,Jogador jogador1,Jogador jogador2)
	{

		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		jogadorAtual = jogador1;
		this.controladorTelas = controladorTelas;
		transicaoTurno = false;
		jogoEncerrado = false;
		
	}
	
	public void mudarVezFasePosicionamento(Arma armas[][])
	{
		if (jogadorAtual == jogador1) 
		{
			jogador1.setArmas(armas);
			jogadorAtual = jogador2;
		} 
		else 
		{
			jogador2.setArmas(armas);
			jogadorAtual = jogador1;
			oponente = jogador2;
			transicaoTurno = true;
			controladorTelas.FaseDeAtaques();
		}
	}
	
	public boolean mudarVezFaseAtaques()
	{
		if(jogoEncerrado)
		{
			controladorTelas.voltarMenuPrincipal();
			return true;
		}
		else
		{
			
			if(transicaoTurno)
			{
				transicaoTurno = false;
			}
			
			else if(!transicaoTurno && jogadorAtual == jogador1 )
			{
				jogadorAtual = jogador2;
				oponente = jogador1;
				transicaoTurno = true;
				
			}
			else if(!transicaoTurno && jogadorAtual == jogador2)
			{
				jogadorAtual = jogador1;
				oponente = jogador2;
				transicaoTurno = true;
				
			}
			return false;
		}

			
	}
	
	public void encerrarJogo()
	{
		jogoEncerrado = true;
	}
	
	public Jogador getJogadorAtual( )
	{
		return jogadorAtual;
	}
	
	public boolean getTransicao()
	{
		return transicaoTurno;
	}
	
	
	public Jogador getOponente() {
		
		return oponente;
	}
	
	public boolean getJogoEncerrado()
	{
		return jogoEncerrado;
	}



	
	
	
}