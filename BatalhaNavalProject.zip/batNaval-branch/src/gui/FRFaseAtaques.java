package gui;

import regras.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import controlador.ControladorTelas;

public class FRFaseAtaques extends JFrame 
{
	final int LARG_DEFAULT=1280;
	final int ALT_DEFAULT=720;
	
	
	
	
	public FRFaseAtaques(FachadaFaseAtaques fachada, ControladorTelas jogo) {
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension screenSize=tk.getScreenSize();
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menuJogo = new JMenu("Menu");
		menuBar.add(menuJogo);
		
		JMenuItem salvar = new JMenuItem("Salvar");
		JMenuItem encerrarJogo = new JMenuItem("Encerrar Jogo");
		
		menuJogo.add(salvar);
		menuJogo.add(encerrarJogo);
		
		salvar.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	jogo.salvarJogo();

	        }
	    });
		
		encerrarJogo.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	setVisible(false);
	        	new ControladorTelas();

	        }
	    });
		
		PNFaseAtaques Jpanel = new PNFaseAtaques(fachada);
		int sl=screenSize.width;
		int sa=screenSize.height;
		int x=sl/2-LARG_DEFAULT/2;
		int y=sa/2-ALT_DEFAULT/2;
		setBounds(x, y-20,LARG_DEFAULT,ALT_DEFAULT);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().add(Jpanel);
		setTitle("Batalha Naval");
		
		
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
}
