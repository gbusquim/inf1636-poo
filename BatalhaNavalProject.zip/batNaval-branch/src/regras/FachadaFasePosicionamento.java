package regras;

import controlador.ControladorJogo;

public class FachadaFasePosicionamento {
	private static FachadaFasePosicionamento fachada=null;
	private static RegrasFasePosicionamento ctrlRegrasPosicionamento;
	private ControladorJogo controlador;
	
	
	private FachadaFasePosicionamento() 
	{
		
	}
	
	public static FachadaFasePosicionamento getFachada() 
	{
		if(fachada==null)
			fachada=new FachadaFasePosicionamento();
		ctrlRegrasPosicionamento=new RegrasFasePosicionamento();
		return fachada;
	}
	
	public void setControlador (ControladorJogo controlador)
	{
		this.controlador = controlador;
	}
	
	public String[][] getMatriz(Arma[][] matrizArmas)
	{
		String[][] matrizTipos= new String [matrizArmas.length][matrizArmas[0].length];
		Arma armaAtual=null;

		for(int i=0; i<matrizArmas.length; i++)
		{
		  for(int j=0; j<matrizArmas[0].length; j++)
		  {
			  armaAtual = matrizArmas[i][j];
			  if(armaAtual == null)
				  matrizTipos[i][j] = "espacoVazio";
			  else
			  {
				  if(armaAtual.estaSelecionada())
					  matrizTipos[i][j] = "armaSelecionada";
				  else
					  matrizTipos[i][j] = armaAtual.getTipo();
	
			  }
				  
		  }
		}
		return matrizTipos;
	}
	
	public void verificaNavioSelecionado(String pos,int i,int j)
	{
		ctrlRegrasPosicionamento.selecionarArma(pos,i,j);
	
	}
	
	public String getNomeJogadorAtual()
	{
		return controlador.getJogadorAtual().getNome();
	}

	public void deselecionaNavio()
	{
		ctrlRegrasPosicionamento.deselecionaNavio();
	}
	
	public void registrar(Observer observer)
	{
		ctrlRegrasPosicionamento.addObserver(observer);
	}

	public void rotacionarArma()
	{
		ctrlRegrasPosicionamento.rotacionarArma();
	}

	public boolean getStatusTabuleiro() 
	{
		return ctrlRegrasPosicionamento.getStatusTabuleiro();
	}
	
	public void avancarTurno() 
	{
		controlador.mudarVezFasePosicionamento(ctrlRegrasPosicionamento.getMatrizTabuleiro(),ctrlRegrasPosicionamento.getVetorArmas());
		ctrlRegrasPosicionamento.limparTabuleiro();
	}
	
	private void exibirMatriz(String[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}

}
