package regras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import controlador.ControladorJogo;
import controlador.ControladorTelas;

public class DAO 
{
	private static DAO acessoArquivos = null;
		
	private DAO() 
	{
		
	}
	
	public static DAO getDAO() 
	{
		if (acessoArquivos == null) 
		{
			acessoArquivos = new DAO();
		}
		return acessoArquivos;
	}
	
	public void salvarJogo(ControladorJogo controladorJogo) 
	{
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showSaveDialog(null);
		int numTirosAgua,numCasasDestruidas;
		Jogador jogadorAtual = controladorJogo.getJogadorAtual();
		Jogador oponente = controladorJogo.getOponente();
		Jogador[] vetorJogadores = new Jogador[]{jogadorAtual,oponente};
		Arma[] vetorArmas;
		int [][] casasDestruidas,tirosAgua;
        if (resultado == JFileChooser.APPROVE_OPTION) 
        {
			try
			{
				FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() +".txt");
				
				for(int i = 0;i<2;i++)
				{
					Jogador jogador = vetorJogadores[i];
					vetorArmas = jogador.getVetorArmas();
					tirosAgua = jogador.getTirosAgua();
					numTirosAgua = jogador.getNumTirosAgua();
					fileWriter.write("nome " + jogador.getNome() + "\n");
					fileWriter.write("numCasasRestantes " + jogador.getCasasRestantes() + "\n");
					fileWriter.write("numTirosAgua " + numTirosAgua + "\n");
					for(int j =0;j<numTirosAgua;j++)
					{
						fileWriter.write(Integer.toString(tirosAgua[j][0]) + " " + Integer.toString(tirosAgua[j][1]) + "\n" );
					}
					fileWriter.write("\n");
					for(int j =0;j<15;j++)
					{
						Arma armaAtual = vetorArmas[j];
						numCasasDestruidas = armaAtual.getNumCasasDestruidas();
						int[] coordCentral = armaAtual.getCoordCentral();
						casasDestruidas = armaAtual.getCasasDestruidas();
						fileWriter.write("tipoArma " + armaAtual.getTipo() + "\n");
						fileWriter.write("direcaoArma " + armaAtual.getDirecao() + "\n");
						fileWriter.write(Integer.toString(coordCentral[0]) + " " + Integer.toString(coordCentral[1]) + "\n");
						fileWriter.write("casasDestruidas " + numCasasDestruidas +"\n");
						for(int k =0;k<numCasasDestruidas;k++)
						{
							fileWriter.write(Integer.toString(casasDestruidas[k][0]) + " " + Integer.toString(casasDestruidas[k][1]) + "\n" );
						}
						fileWriter.write("\n");
					}
					fileWriter.write("\n");

				}
				fileWriter.close();
			} 
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
	    }
	}
	
	public ControladorJogo recarregar(ControladorTelas controladorTela) throws Exception 
	{
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showOpenDialog(null);
		String dados[],nomeJogador,tipoArma,direcaoArma;
		int numTirosAgua,numCasasDestruidas;
		int coordCentral [];
		Jogador vetorJogadores[] = new Jogador [2];
		Jogador jogador;
		Arma matrizArmas[][];
		Arma vetorArmas[];
		Arma arma;
		int [][] casasArma;
		ControladorJogo controlador = null;
		
		if (resultado == JFileChooser.APPROVE_OPTION) 
		{
			
			File arquivoEscolhido = fileChooser.getSelectedFile();

		    try 
		    {
	            Scanner scanner = new Scanner(arquivoEscolhido);
	          

	            
	            for(int i=0;i<2;i++)
	            {
	            	
	            	matrizArmas= new Arma [15][15];
	        		vetorArmas = new Arma[15];
	            	dados = scanner.nextLine().split("\\s+");
	           
	            	nomeJogador = dados[1];
	            	jogador = new Jogador(nomeJogador);
	          
	            	dados = scanner.nextLine().split("\\s+");
	            	jogador.setCasasRestantes(Integer.parseInt(dados[1]));
	            	dados = scanner.nextLine().split("\\s+");
	            	numTirosAgua = Integer.parseInt(dados[1]);
	            	for(int j=0;j<numTirosAgua;j++)
	            	{
	            		dados = scanner.nextLine().split("\\s+");
	            		jogador.adicionarTiroAgua(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
	            	}

	            	scanner.nextLine();
	            	
	            	for(int j=0;j<15;j++)
	            	{
	         
	            		dados = scanner.nextLine().split("\\s+");
	            		tipoArma = dados[1];
	            
	            		dados = scanner.nextLine().split("\\s+");
	            		direcaoArma = dados[1];
	            		dados = scanner.nextLine().split("\\s+");
	            		coordCentral = new int[]{Integer.parseInt(dados[0]),Integer.parseInt(dados[1])};
	            		arma = new Arma(tipoArma,coordCentral,direcaoArma);
	            		
	            		dados = scanner.nextLine().split("\\s+");
	
	            		numCasasDestruidas = Integer.parseInt(dados[1]);
	            	
		            	for(int k=0;k<numCasasDestruidas;k++)
		            	{
		            		dados = scanner.nextLine().split("\\s+");
		          
		            		arma.adicionarCasaDestruida(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
		            		
		            	}
		            	vetorArmas[j] = arma;
		            	casasArma = arma.getCasas();
		            	
		    			for(int k = 0;k<casasArma.length;k++)
		    			{
		    				matrizArmas[casasArma[k][0]][casasArma[k][1]] = arma;
		    			}
		    			scanner.nextLine();
		    		
		    			
	            	}
	            	
	            	jogador.setArmas(matrizArmas,vetorArmas);
	            	vetorJogadores[i] = jogador;
	            	scanner.nextLine();
	            	
	        
	            	
	            }
	            
	            controlador = new ControladorJogo(controladorTela,vetorJogadores[0],vetorJogadores[1]);
	            scanner.close();
	        } 
		    catch (IOException e) 
		    {
	            System.out.println(e);
	        } 
		    catch (NumberFormatException e) 
		    {
	        	System.out.println(e);
	        }
		} 
		else if (resultado == JFileChooser.CANCEL_OPTION)
		{
			Exception e = new Exception();
            System.out.println(e);
			throw e;
		}
		return controlador;
	}
	
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
	
}
