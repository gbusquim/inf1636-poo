package regras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import controlador.ControladorJogo;

public class DAO 
{
	private static DAO acessoArquivos = null;
		
	private DAO() 
	{
		
	}
	
	public static DAO getDAO() 
	{
		if (acessoArquivos == null) 
		{
			acessoArquivos = new DAO();
		}
		return acessoArquivos;
	}
	
	public void salvarJogo() 
	{
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showSaveDialog(null);
        if (resultado == JFileChooser.APPROVE_OPTION) 
        {
			try
			{
				FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() +".txt");
				fileWriter.write("TotalJogadores\n");
//			fileWriter.write("\n");
//			Player p = board.getCurrentPlayer();
//			int currentPlayer = p.getNumber();
//			
//			for (int i = 0; i < playersCount; i++) {
//                currentPlayer += 1;
//    			currentPlayer = currentPlayer % board.getPlayers().size();
//                Player player = board.getPlayers().get(currentPlayer);
//                int cardsCount = player.getCards().size();
//                int businessesCount = player.getBusinesses().size();
//                
//                fileWriter.write(player.getName() + "\n"); // name
//                fileWriter.write("Posicao " + player.getPosition() + "\n"); // position
//                fileWriter.write("Capital " + player.getWealth() + "\n"); // wealth
//                fileWriter.write("Preso " + player.getIsArrested() + "\n"); // wealth
//                fileWriter.write("TotalCartas " + cardsCount + "\n");
//                
//                for (int j = 0; j < cardsCount; j++) {
//                	fileWriter.write(player.getCards().get(j).getName() + " ");
//                }
//                
//                fileWriter.write("\n");
//                fileWriter.write("TotalLote " + businessesCount + "\n");
//                
//                for (int j = 0; j < businessesCount; j++) {
//                	fileWriter.write(player.getBusinesses().get(j).getCardTypeName() + " ");
//                	if (player.getBusinesses().get(j) instanceof Property) {
//                		fileWriter.write(((Property) player.getBusinesses().get(j)).getConstructions() + " ");
//                	} else {
//                		fileWriter.write("0 ");
//                	}
//                	
//                }
//               
//                fileWriter.write("\n");
//                fileWriter.write("\n");
//            }
//            
				fileWriter.close();
			} 
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
	    }
	}
	
	public ControladorJogo recarregar() throws Exception 
	{
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showOpenDialog(null);
		String dados[],nomeJogador;
		boolean transicao;
		int vezAtual,numeroJogadas,numCasasAgua,numCasasDestruidas;
		int coordCentral [];
		Jogador vetorJogadores[] = new Jogador [2];
		Jogador jogador;
		Arma matrizArmas[][];
		Arma arma;
		int [][] casasArma;
		ControladorJogo controlador;
		
		if (resultado == JFileChooser.APPROVE_OPTION) 
		{
			File arquivoEscolhido = fileChooser.getSelectedFile();

		    try 
		    {
	            Scanner scanner = new Scanner(arquivoEscolhido);
	            dados = scanner.nextLine().split("\\s+");
	            vezAtual = Integer.parseInt(dados[1]);
	            dados = scanner.nextLine().split("\\s+");
	            transicao = Boolean.valueOf(dados[1]);
	            if(!transicao)
	            {
	            	numeroJogadas = Integer.parseInt(dados[3]);
	            }
	            	
	            scanner.nextLine();
	            
	            for(int i=0;i<2;i++)
	            {
	            	matrizArmas = new Arma[15][15];
	            	dados = scanner.nextLine().split("\\s+");
	            	nomeJogador = dados[1];
	            	jogador = new Jogador(nomeJogador);
	            	dados = scanner.nextLine().split("\\s+");
	            	jogador.setCasasRestantes(Integer.parseInt(dados[1]));
	            	dados = scanner.nextLine().split("\\s+");
	            	numCasasAgua = Integer.parseInt(dados[1]);
	            	for(int j=0;j<numCasasAgua;j++)
	            	{
	            		dados = scanner.nextLine().split("\\s+");
	            		jogador.adicionarTiroAgua(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
	            	}
	            	
	            	for(int j=0;j<1;j++)
	            	{
	            		dados = scanner.nextLine().split("\\s+");
	            		coordCentral = new int[]{Integer.parseInt(dados[2]),Integer.parseInt(dados[3])};
	            		arma = new Arma(dados[0],coordCentral,dados[1]);
	            		dados = scanner.nextLine().split("\\s+");
	            		numCasasDestruidas = Integer.parseInt(dados[1]);
		            	for(int k=0;k<numCasasAgua;k++)
		            	{
		            		dados = scanner.nextLine().split("\\s+");
		            		arma.adicionarCasaDestruida(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
		            	}
		            	casasArma = arma.getCasas();
		    			for(int k = 0;k<casasArma.length;k++)
		    			{
		    				matrizArmas[casasArma[k][0]][casasArma[k][1]] = arma;
		    			}
	            		
	            	}
	            	jogador.setArmas(matrizArmas);
	            	vetorJogadores[i] = jogador;
	            }
	            //controlador = new ControladorJogo();
	            scanner.close();
	        } 
		    catch (IOException e) 
		    {
	            System.out.println(e);
	        } 
		    catch (NumberFormatException e) 
		    {
	        	System.out.println(e);
	        }
		} 
		else if (resultado == JFileChooser.CANCEL_OPTION)
		{
			Exception e = new Exception();
            System.out.println(e);
			throw e;
		}
		return null;
	}
}
