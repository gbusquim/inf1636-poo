package regras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import controlador.ControladorJogo;
import controlador.ControladorTelas;

public class DAO 
{
	private static DAO acessoArquivos = null;
		
	private DAO() 
	{
		
	}
	
	public static DAO getDAO() 
	{
		if (acessoArquivos == null) 
		{
			acessoArquivos = new DAO();
		}
		return acessoArquivos;
	}
	
	public void salvarJogo(ControladorJogo controladorJogo) 
	{
		
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showSaveDialog(null);
		Jogador jogadorAtual = controladorJogo.getJogadorAtual();
		Jogador oponente = controladorJogo.getOponente();
		Jogador jogador = jogadorAtual;
		Arma[] vetorArmas;
		int [][] casasDestruidas,tirosAgua;
        if (resultado == JFileChooser.APPROVE_OPTION) 
        {
			try
			{
				FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() +".txt");
				
				for(int i = 0;i<2;i++)
				{
					vetorArmas = jogador.getVetorArmas();
					tirosAgua = jogador.getTirosAgua();
					fileWriter.write("nome " + jogador.getNome());
					fileWriter.write("numCasasRestantes " + jogador.getCasasRestantes());
					fileWriter.write("numTirosAgua " + tirosAgua.length);
					System.out.println(tirosAgua.length);
					for(int j =0;j<tirosAgua.length;j++)
					{
						fileWriter.write(Integer.toString(tirosAgua[i][0]) + " " + Integer.toString(tirosAgua[i][1]));
					}
					for(int j =0;j<vetorArmas.length;j++)
					{
						Arma armaAtual = vetorArmas[j];
						//fileWriter.write(armaAtual.getTipo() + armaAtual.getDirecao() + armaAtual.);
					}
					
					
					
				}
				fileWriter.write("TotalJogadores\n");
				
//			fileWriter.write("\n");
//			Player p = board.getCurrentPlayer();
//			int currentPlayer = p.getNumber();
//			
//			for (int i = 0; i < playersCount; i++) {
//                currentPlayer += 1;
//    			currentPlayer = currentPlayer % board.getPlayers().size();
//                Player player = board.getPlayers().get(currentPlayer);
//                int cardsCount = player.getCards().size();
//                int businessesCount = player.getBusinesses().size();
//                
//                fileWriter.write(player.getName() + "\n"); // name
//                fileWriter.write("Posicao " + player.getPosition() + "\n"); // position
//                fileWriter.write("Capital " + player.getWealth() + "\n"); // wealth
//                fileWriter.write("Preso " + player.getIsArrested() + "\n"); // wealth
//                fileWriter.write("TotalCartas " + cardsCount + "\n");
//                
//                for (int j = 0; j < cardsCount; j++) {
//                	fileWriter.write(player.getCards().get(j).getName() + " ");
//                }
//                
//                fileWriter.write("\n");
//                fileWriter.write("TotalLote " + businessesCount + "\n");
//                
//                for (int j = 0; j < businessesCount; j++) {
//                	fileWriter.write(player.getBusinesses().get(j).getCardTypeName() + " ");
//                	if (player.getBusinesses().get(j) instanceof Property) {
//                		fileWriter.write(((Property) player.getBusinesses().get(j)).getConstructions() + " ");
//                	} else {
//                		fileWriter.write("0 ");
//                	}
//                	
//                }
//               
//                fileWriter.write("\n");
//                fileWriter.write("\n");
//            }
            
				fileWriter.close();
			} 
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
	    }
	}
	
	public ControladorJogo recarregar(ControladorTelas controladorTela) throws Exception 
	{
		JFileChooser fileChooser = new JFileChooser();
		fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
		int resultado = fileChooser.showOpenDialog(null);
		String dados[],nomeJogador;
		int numCasasAgua,numCasasDestruidas;
		int coordCentral [];
		Jogador vetorJogadores[] = new Jogador [2];
		Jogador jogador;
		Arma matrizArmas[][] = new Arma [15][15];
		Arma vetorArmas[] = new Arma[15];
		Arma arma;
		int [][] casasArma;
		ControladorJogo controlador = null;
		
		if (resultado == JFileChooser.APPROVE_OPTION) 
		{
			
			File arquivoEscolhido = fileChooser.getSelectedFile();

		    try 
		    {
	            Scanner scanner = new Scanner(arquivoEscolhido);
	            
	            dados = scanner.nextLine().split("\\s+");

	            
	            for(int i=0;i<2;i++)
	            {
	    
	            	matrizArmas = new Arma[15][15];
	            	dados = scanner.nextLine().split("\\s+");
	            	nomeJogador = dados[1];
	            	jogador = new Jogador(nomeJogador);
	          
	            	dados = scanner.nextLine().split("\\s+");
	            	jogador.setCasasRestantes(Integer.parseInt(dados[1]));
	            	dados = scanner.nextLine().split("\\s+");
	            	numCasasAgua = Integer.parseInt(dados[1]);
	            	for(int j=0;j<numCasasAgua;j++)
	            	{
	            		dados = scanner.nextLine().split("\\s+");
	            		jogador.adicionarTiroAgua(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
	            	}
	            	
	            	for(int j=0;j<1;j++)
	            	{
	            		dados = scanner.nextLine().split("\\s+");
	            		coordCentral = new int[]{Integer.parseInt(dados[2]),Integer.parseInt(dados[3])};
	            		arma = new Arma(dados[0],coordCentral,dados[1]);
	            		
	            		dados = scanner.nextLine().split("\\s+");
	            		numCasasDestruidas = Integer.parseInt(dados[1]);
		            	for(int k=0;k<numCasasDestruidas;k++)
		            	{
		            		dados = scanner.nextLine().split("\\s+");
		            		arma.adicionarCasaDestruida(Integer.parseInt(dados[0]), Integer.parseInt(dados[1]));
		            		
		            	}
		            	vetorArmas[j] = arma;
		            	casasArma = arma.getCasas();
		            	
		    			for(int k = 0;k<casasArma.length;k++)
		    			{
		    				matrizArmas[casasArma[k][0]][casasArma[k][1]] = arma;
		    			}
		    			
	            	}
	            	jogador.setArmas(matrizArmas,vetorArmas);
	            	vetorJogadores[i] = jogador;
	        
	            	
	            }
	            
	            controlador = new ControladorJogo(controladorTela,vetorJogadores[0],vetorJogadores[1]);
	            scanner.close();
	        } 
		    catch (IOException e) 
		    {
	            System.out.println(e);
	        } 
		    catch (NumberFormatException e) 
		    {
	        	System.out.println(e);
	        }
		} 
		else if (resultado == JFileChooser.CANCEL_OPTION)
		{
			Exception e = new Exception();
            System.out.println(e);
			throw e;
		}
		return controlador;
	}
	
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
	
}
