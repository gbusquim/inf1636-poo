package controlador;

import gui.*;
import regras.DAO;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;
import regras.Jogador;

public class ControladorTelas {
	
	private FREscolherModoJogo emjFrame;
	private FREscolherNomesJogadores enjFrame;
	private FRFasePosicionamento fpFrame;
	private FRFaseAtaques faFrame;
	private ControladorJogo controlador;
	
	private static ControladorTelas controladorTelas = null;
	
	private ControladorTelas() 
	{
		emjFrame = new FREscolherModoJogo(this);
	}
	
	public static ControladorTelas getControladorTelas() 
	{
		if (controladorTelas == null) 
		{
			controladorTelas = new ControladorTelas();
			
		}
		return controladorTelas;
	}

	public void NovoJogo( ) {
		emjFrame.setVisible(false);
		enjFrame = new FREscolherNomesJogadores(this);
	}
	public void IniciarJogo(String nomeJogador1,String nomeJogador2) {
		enjFrame.setVisible(false);
		Jogador jogador1 = new Jogador(nomeJogador1);
		Jogador jogador2 = new Jogador(nomeJogador2);
		controlador = ControladorJogo.getInstance();
		controlador.inicializarControlador(this,jogador1,jogador2);
		FachadaFasePosicionamento fachadaPosicionamento = FachadaFasePosicionamento.getInstance();
		fachadaPosicionamento.setControlador(controlador);
		fpFrame = new FRFasePosicionamento(fachadaPosicionamento,this);
		fpFrame.setVisible(true);
	}
	public void FaseDeAtaques( ) {
		fpFrame.setVisible(false);
		emjFrame.setVisible(false);
		FachadaFaseAtaques fachadaAtaques = FachadaFaseAtaques.getInstance();
		fachadaAtaques.setControlador(controlador);
		faFrame = new FRFaseAtaques(fachadaAtaques,this);
		faFrame.setVisible(true);
	}
	
	public static void main(String[] args) {
		new ControladorTelas();
	}
	
	public void voltarMenuPrincipalFaseAtaques()
	{
			faFrame.setVisible(false);
			emjFrame.setVisible(true);
	}
		
	public void voltarMenuPrincipalFasePosicionamento()
	{
			fpFrame.setVisible(false);
			emjFrame.setVisible(true);
	}
	
	public void CarregarJogo() 
	{

		controlador = DAO.getInstance().recarregar(this);
		if(controlador!=null)
		{
			if(emjFrame.isVisible())
				emjFrame.setVisible(false);
			else if(fpFrame.isVisible())
				fpFrame.setVisible(false);
			FachadaFaseAtaques fachadaAtaques = FachadaFaseAtaques.getInstance();
			fachadaAtaques.setControlador(controlador);
			faFrame = new FRFaseAtaques(fachadaAtaques,this);
			faFrame.setVisible(true);
		} 
			 

	}
	public void salvarJogo() {
		DAO.getInstance().salvarJogo(controlador);
		
	}
}