package regras;

import java.util.ArrayList;
import java.util.List;

public class RegrasFaseAtaques implements Observable {
	private static RegrasFaseAtaques regrasFaseAtaques = null;
	Jogador oponente;
	private List<Observer> listaObservers;
	private boolean fimTurno;
	private String mensagem;
	private boolean fimJogo;
	private int numJogadas;
	
	
	private RegrasFaseAtaques() 
	{
		
	}
	
	public static RegrasFaseAtaques getInstance() 
	{
		if (regrasFaseAtaques == null) 
		{
			regrasFaseAtaques = new RegrasFaseAtaques();
		}
		return regrasFaseAtaques;
	}
	
	public void inicializarRegrasAtaque(Jogador oponente)
	{
		listaObservers = new ArrayList<Observer>();
		this.oponente = oponente;
		fimTurno = false;
		fimJogo = false;
		numJogadas = 0;
		
	}
	
	
	public void verificarCasaSelecionada(int i,int j)
	{
		if (!fimTurno)
		{
			Arma armaSelecionada = oponente.getMatrizArmas()[i][j];
			boolean jogadaValida = false;
			if(armaSelecionada == null)
			{
				jogadaValida = oponente.adicionarTiroAgua(i,j);
				if(jogadaValida)
				{
					mensagem = "Jogada " + Integer.toString(numJogadas+1) +": Voc� acertou um tiro na �gua";
					aumentarNumeroJogadas();
					notificarObservers();
				}
			}
			else
			{
				if(!armaSelecionada.foiDestruida())
				{
					jogadaValida = armaSelecionada.adicionarCasaDestruida(i, j);
					if(jogadaValida)
					{
						String tipoArma = armaSelecionada.getTipo();
						if(armaSelecionada.foiDestruida())
							mensagem = "Jogada " + Integer.toString(numJogadas+1) +": Voc� destruiu um "+ tipoArma;
						else
							mensagem = "Jogada " + Integer.toString(numJogadas+1) +": Voc� destruiu parte de um "+ tipoArma;
						fimJogo = oponente.diminuirCasasRestantes();
						aumentarNumeroJogadas();
						notificarObservers();
						
					}
				}
			}
		}
	}
	
	
	public void travarTurno()
	{
		fimTurno = true;
		notificarObservers();
	}
	
	
	public void novoTurno(Jogador oponente)
	{
		fimTurno = false;
		this.oponente = oponente;
		numJogadas = 0;
		mensagem="Clique em uma casa do oponente!";
		notificarObservers();
	}
	
	public void aumentarNumeroJogadas() {
		numJogadas++;
		if(numJogadas == 3 || fimJogo)
		{
			fimTurno = true;
			
		}
		
	}


	public void addObserver(Observer o)
	{
		listaObservers.add(o);
	}

	public void removeObserver(Observer o)
	{
		listaObservers.remove(o);
	}
	
	private void notificarObservers()
	{
		for(Observer o: listaObservers) 
		{
			o.notify(this);
		}
	}


	public Object get() 
	{	
		Object dados[]=new Object[4];	
		dados[0]=oponente;
		dados[1] = String.valueOf(mensagem);
		dados[2]=Boolean.valueOf(fimTurno);
		dados[3]= Boolean.valueOf(fimJogo);
		

		return dados;
	}

	
}
