package regras;

public class Jogador 
{
	private String nome;
	private Arma[][] matrizArmas;
	private Arma[] vetorArmas;
	private int[][] tirosNaAgua;
	private int numCasasRestantes;
	private int numTirosAgua;
	
	
	public Jogador(String nome)
	{
		this.nome = nome;
		matrizArmas = new Arma[15][15];
		vetorArmas = new Arma[15];
		tirosNaAgua = new int [225][2];
		numCasasRestantes = 38;
		numTirosAgua = 0;
	}
	
	public void setArmas(Arma matrizArmas[][],Arma vetorArmas[])
	{
		for (int i = 0; i < 15; i++)
			for (int j = 0; j < 15; j++)
				this.matrizArmas[i][j] = matrizArmas[i][j];
		for(int i = 0; i < 15; i++)
		{
			this.vetorArmas[i] = vetorArmas[i];
		}
	}
	public Arma[][] getMatrizArmas( )
	{
		
		return matrizArmas;
	}
	public String getNome()
	{
		return nome;
	}
	
	
	
	
	
	public boolean verificarTiroAgua(int i,int j) 
	{
		for(int contador=0;contador<numTirosAgua;contador++)
		{
			if(tirosNaAgua[contador][0] == i && tirosNaAgua[contador][1] == j)
				return true;
		}
		return false;

	}

	public boolean adicionarTiroAgua(int i, int j)
	{
		boolean existeTiroNaAgua = verificarTiroAgua(i,j);
		if(!existeTiroNaAgua)
		{
			tirosNaAgua[numTirosAgua][0] = i;
			tirosNaAgua[numTirosAgua][1] = j;
			numTirosAgua++;
			return true;
		}
		return false;
	}
	
	public boolean diminuirCasasRestantes()
	{
		numCasasRestantes--;
		return numCasasRestantes == 0;
	}
	
	public void setCasasRestantes(int numCasasRestantes)
	{
		this.numCasasRestantes = numCasasRestantes;
	}
	public int[][] getTirosAgua() {
		
		return tirosNaAgua;
	}
	
	public int getCasasRestantes() {
		
		return numCasasRestantes;
	}
	public Arma[] getVetorArmas() {
		
		return vetorArmas;
	}
	public int getNumTirosAgua() {
		return numTirosAgua;
	}
	

		
	
}
