package regras;

import java.util.ArrayList;
import java.util.List;

public class RegrasFaseAtaques {
	//Arma[][] matrizJogadorAtual;
	Arma[][] matrizOponente; 
	private List<Observer> listaObservers = new ArrayList<Observer>();
	private int [][]listaCasasAgua = new int[225][2];//mudar para um tamanho compativel dps
	private int numCasasAgua =0;
	
	
	
	public RegrasFaseAtaques()
	{
		//matrizJogadorAtual =  new Arma[15][15]; 
		matrizOponente = new Arma[15][15];
	}
	
	
	public void setMatriz(Arma[][] matrizArmas,String tipoMatriz)
	{
		  for (int i = 0; i < 15; i++) 
		  {  
		       for (int j = 0; j < 15; j++)     
		       {
		    	  // if(tipoMatriz == "JogadorAtual")
		    		//   matrizJogadorAtual[i][j] = matrizArmas[i][j]; 
		    	  if(tipoMatriz == "Oponente")
		    		   matrizOponente[i][j] = matrizArmas[i][j]; 
		       }  
	
		  }
	}
	
	public boolean verificarCasaSelecionada(int i,int j)
	{
		Arma armaSelecionada = matrizOponente[i][j];
		if(armaSelecionada == null && !checarCoordenadaDentroLista(listaCasasAgua,i,j))
		{
			listaCasasAgua[numCasasAgua][0] = i;
			listaCasasAgua[numCasasAgua][1] = j;
			numCasasAgua++;
			return true;
		}
		else if(matrizOponente[i][j] != null)
		{
			if(!armaSelecionada.foiDestruida())
			{
				boolean jogadaValida = armaSelecionada.verificarCasasDestruidas(i, j);
				if(jogadaValida)
					return true;

			}
		}
		return false;
	}
	
	
	private boolean checarCoordenadaDentroLista(int[][] lista, int i, int j) // mudar para validarTiroAgua se n tiver mais nada p fazer
	{
		for(int[] elem: lista)
		{
			if(elem[0] == i && elem[1] == j)
				return true;
		}
		return false;
	}

	
}
