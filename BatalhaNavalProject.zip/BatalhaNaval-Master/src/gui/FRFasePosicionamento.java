package gui;

import regras.*;

import java.awt.*;
import javax.swing.*;

public class FRFasePosicionamento extends JFrame {
	final int LARG_DEFAULT=1280;
	final int ALT_DEFAULT=720;
	
	
	
	
	FRFasePosicionamento(Fachada fachada) {
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension screenSize=tk.getScreenSize();
		
		
		PNFasePosicionamento Jpanel = new PNFasePosicionamento(fachada);
		int sl=screenSize.width;
		int sa=screenSize.height;
		int x=sl/2-LARG_DEFAULT/2;
		int y=sa/2-ALT_DEFAULT/2;
		setBounds(x, y-20,LARG_DEFAULT,ALT_DEFAULT);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().add(Jpanel);
		setTitle("Batalha Naval");
		
		
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
}
