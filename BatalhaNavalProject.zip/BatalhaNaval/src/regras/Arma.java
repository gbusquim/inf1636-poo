package regras;

public class Arma 
{
	private String tipo;
	private int[] coords;
	private String direcao;
	private int numCasas;
	private boolean selecionada;
	private boolean inserida;
	private boolean setCoordsTeste;
	
	
	public Arma(String tipo,int[] coords)
	{
		selecionada = false;
		inserida = false;
		setCoordsTeste = false;
		this.tipo = tipo;
		direcao = "esquerda";
		this.coords = coords;
		if(tipo=="h")
		{
			direcao = "cima";
			numCasas= 3;
			this.coords[1] +=1;
		}
		else if(tipo == "s")
			numCasas= 1;
		else if(tipo == "d")
			numCasas= 2;
		else if(tipo == "cr")
			numCasas= 4;
		else if(tipo == "co")
			numCasas= 5;
	}
	
	public void setCoordenadas(int i,int j)
	{
		
		coords[0]=i;
		coords[1]=j;
		if(tipo == "h" && !setCoordsTeste)
		{
			if(direcao == "direita") 
				coords[1]=j-1;
			if(direcao == "esquerda") 
				coords[1]=j+1;
			else if(direcao == "cima")
				coords[0]=i+1;
			else if(direcao == "baixo")
				coords[0]=i-1;
		}
			
	}
	
	public boolean estaSelecionada()
	{
		return selecionada;
	}
	
	public boolean foiInserida()
	{
		return inserida;
	}
	
	public void tornarInserida()
	{
		inserida = true;
	}
	
	public void alterarStatusArma(boolean status)
	{
		selecionada = status;
	}
	
	public String getTipo()
	{
		return tipo;
	}
	
	public String getDirecao()
	{
		return direcao;
	}
	
	public void alterarDirecaoNoventaGraus(Boolean sentido)
	{
		if(sentido == true)
		{
			if(direcao == "cima")
				direcao = "direita";
			else if(direcao == "direita")
				direcao = "baixo";
			else if(direcao == "baixo")
				direcao = "esquerda";
			else if(direcao == "esquerda")
				direcao = "cima";
		}
		else
		{
			if(direcao == "cima")
				direcao = "esquerda";
			else if(direcao == "esquerda")
				direcao = "baixo";
			else if(direcao == "baixo")
				direcao = "direita";
			else if(direcao == "direita")
				direcao = "cima";
		}
		
	}
	
	public int[][] getCasas()
	{
		int[][] matrizCasas = new int[numCasas][2];
		int cont;
		if(tipo == "h")
		{
			if(direcao == "cima")
			{
				//for(cont = 0;cont < numCasas; cont++)
				matrizCasas[0][0]=coords[0];
				matrizCasas[0][1]=coords[1]-1;
				matrizCasas[1][0]=coords[0]-1;
				matrizCasas[1][1]=coords[1];
				matrizCasas[2][0]=coords[0];
				matrizCasas[2][1]=coords[1]+1;
			}
			else if(direcao == "direita")
			{
				matrizCasas[0][0]=coords[0]-1;
				matrizCasas[0][1]=coords[1];
				matrizCasas[1][0]=coords[0];
				matrizCasas[1][1]=coords[1]+1;
				matrizCasas[2][0]=coords[0]+1;
				matrizCasas[2][1]=coords[1];
			}
			else if(direcao == "baixo")
			{
				matrizCasas[0][0]=coords[0];
				matrizCasas[0][1]=coords[1]-1;
				matrizCasas[1][0]=coords[0];
				matrizCasas[1][1]=coords[1]+1;
				matrizCasas[2][0]=coords[0]+1;
				matrizCasas[2][1]=coords[1];
			}
			else if(direcao == "esquerda")
			{
				matrizCasas[0][0]=coords[0]-1;
				matrizCasas[0][1]=coords[1];
				matrizCasas[1][0]=coords[0];
				matrizCasas[1][1]=coords[1]-1;
				matrizCasas[2][0]=coords[0]+1;
				matrizCasas[2][1]=coords[1];
			}
		}
		
		return matrizCasas;
	}
	
	
//	
//	private boolean testaPossivelInserir(int i,int j)
//	{
//		if(tipoNavioSelecionado == "h")
//		{
//			if(j>12 || i == 0)
//			{
//				
//				return false;
//			}
//			else
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i-1][j+1] != "" || tabuleiro[i][j+2] != "" )
//					return false;
//					
//				if (tabuleiro[i][j+1] != "" || tabuleiro[i-1][j] != "" || tabuleiro[i-1][j+2] != "")
//					return false;
//
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1] != "")
//						return false;
//					
//					if(tabuleiro[i-1][j-1] != "")
//						return false;
//					
//					if(i != 14)
//					{
//						if(tabuleiro[i+1][j-1] != "")
//							return false;
//					}
//
//				}
//				if(j!=14)
//				{ 
//					if(tabuleiro[i][j+3] != "" || tabuleiro[i-1][j+3] != "")
//						return false;
//					if(i!=14)
//					{
//						if(tabuleiro[i+1][j+3] != "" )
//							return false;
//					}
//				}
//				if(i>1)
//				{
//					if(tabuleiro[i-2][j] != "" || tabuleiro[i-2][j+1] != "" || tabuleiro[i-2][j+2] != "")
//						return false;
//				}
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j] != "" || tabuleiro[i+1][j+1] != "" || tabuleiro[i+1][j+2] != "")
//						return false;
//				}
//				
//
//			}
//		}
//		
//	
//		
//		else if(tipoNavioSelecionado == "s")
//		{
//			if(tabuleiro[i][j]!="")
//				return false;
//			
//			if(i!=0)
//			{
//				if(tabuleiro[i-1][j]!="")
//					return false;
//				if (j!=0)
//				{
//					if(tabuleiro[i-1][j-1]!="")
//						return false;
//				}
//				if (j!=14)
//				{
//					if(tabuleiro[i-1][j+1]!="")
//						return false;
//				}
//			}
//			
//			if(i!=14)
//			{
//				if(tabuleiro[i+1][j]!="")
//					return false;
//				if (j!=14)
//				{
//					if(tabuleiro[i+1][j+1]!="")
//						return false;
//				}
//				if (j!=0)
//				{
//					if(tabuleiro[i+1][j-1]!="")
//						return false;
//				}
//			}
//			if(j!=0)
//			{
//				if(tabuleiro[i][j-1]!="")
//					return false;
//			}
//			if(j!=14)
//			{
//				if(tabuleiro[i][j+1]!="")
//					return false;
//			}
//			
//		}
//		
//		else if(tipoNavioSelecionado == "d")
//		{
//			
//			if(j==14)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+2]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+2]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+2]!="")
//						return false;
//				}
//			}
//		}
//			
//		else if(tipoNavioSelecionado == "cr")
//		{
//			
//			if(j>11)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+4]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+4]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+4]!="")
//						return false;
//				}
//			}
//		}
//		
//		else if(tipoNavioSelecionado == "co")
//		{
//			System.out.println("ue");
//			if(j>10)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="" || tabuleiro[i][j+4]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="" || tabuleiro[i-1][j+4]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+5]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="" || tabuleiro[i+1][j+4]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+5]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+5]!="")
//						return false;
//				}
//			}
//		}
//		return true;
//			
//	}
//	
	public boolean testaEncaixaTabuleiro(int i,int j)
	{
		int coordAntigaX = coords[0];
		int coordAntigaY = coords[1];
		setCoordenadas(i,j);
		int [][] casasArma = getCasas();
		setCoordsTeste = true;
		for (int linha = 0;linha<casasArma.length;linha++)
		{
			if(casasArma[linha][0]<0 || casasArma[linha][0]>14 || casasArma[linha][1]<0 || casasArma[linha][1]>14 )
			{
				setCoordenadas(coordAntigaX,coordAntigaY);
				setCoordsTeste = false;
				return false;
			}
		}
		setCoordenadas(coordAntigaX,coordAntigaY);
		setCoordsTeste = false;
		return true;
	}
	
	
	public boolean testaEncaixaTabuleiro()
	{
		int [][] casasArma = getCasas();
		for (int linha = 0;linha<casasArma.length;linha++)
		{
			if(casasArma[linha][0]<0 || casasArma[linha][0]>14 || casasArma[linha][1]<0 || casasArma[linha][1]>14 )
			{

				return false;
			}
		}

		return true;
	}
	
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
}


