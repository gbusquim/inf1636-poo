package regras;

public class Arma 
{
	private String tipo;
	private int[] coords;
	private String direcao;
	private int numCasas;
	private boolean selecionada;
	
	
	public Arma(String tipo,int[][] coords)
	{
		selecionada = true;
		direcao = "esquerda";
		this.tipo = tipo;
		if(tipo=="h")
			numCasas= 3;
		else if(tipo == "s")
			numCasas= 1;
		else if(tipo == "d")
			numCasas= 2;
		else if(tipo == "cr")
			numCasas= 4;
		else if(tipo == "co")
			numCasas= 5;
		this.coords = new int[2];
//		for(int i=0; i<numCasas; i++)
//			  for(int j=0; j<2; j++)
//			    this.coords[i][j]=coords[i][j];
		this.coords = coords[0];
	}
	
	public int[]getCoordX()
	{
		return coords;
	}
	
	public boolean estaSelecionada()
	{
		return selecionada;
	}
	
	public void alterarStatusArma(boolean status)
	{
		if(status == true)
			selecionada = true;
		else
			selecionada = false;
	}
	
	public String getTipo()
	{
		return tipo;
	}
	
//	public int getNumeroCasas()
//	{
//		return numCasas;
//	}
	
	public int[][] getCasas()
	{
		int[][] matrizCasas = new int[numCasas][2];
		int cont;
		if(tipo == "h")
		{
			if(direcao == "esquerda")
			{
				//for(cont = 0;cont < numCasas; cont++)
				matrizCasas[0][0]=coords[0];
				matrizCasas[0][0]=coords[1]-1;
				matrizCasas[1][0]=coords[0]+1;
				matrizCasas[1][0]=coords[1];
				matrizCasas[2][0]=coords[0];
				matrizCasas[2][0]=coords[1]+1;
			}
		}
		return matrizCasas;
	}
	
	
//	
//	private boolean testaPossivelInserir(int i,int j)
//	{
//		if(tipoNavioSelecionado == "h")
//		{
//			if(j>12 || i == 0)
//			{
//				
//				return false;
//			}
//			else
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i-1][j+1] != "" || tabuleiro[i][j+2] != "" )
//					return false;
//					
//				if (tabuleiro[i][j+1] != "" || tabuleiro[i-1][j] != "" || tabuleiro[i-1][j+2] != "")
//					return false;
//
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1] != "")
//						return false;
//					
//					if(tabuleiro[i-1][j-1] != "")
//						return false;
//					
//					if(i != 14)
//					{
//						if(tabuleiro[i+1][j-1] != "")
//							return false;
//					}
//
//				}
//				if(j!=14)
//				{ 
//					if(tabuleiro[i][j+3] != "" || tabuleiro[i-1][j+3] != "")
//						return false;
//					if(i!=14)
//					{
//						if(tabuleiro[i+1][j+3] != "" )
//							return false;
//					}
//				}
//				if(i>1)
//				{
//					if(tabuleiro[i-2][j] != "" || tabuleiro[i-2][j+1] != "" || tabuleiro[i-2][j+2] != "")
//						return false;
//				}
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j] != "" || tabuleiro[i+1][j+1] != "" || tabuleiro[i+1][j+2] != "")
//						return false;
//				}
//				
//
//			}
//		}
//		
//	
//		
//		else if(tipoNavioSelecionado == "s")
//		{
//			if(tabuleiro[i][j]!="")
//				return false;
//			
//			if(i!=0)
//			{
//				if(tabuleiro[i-1][j]!="")
//					return false;
//				if (j!=0)
//				{
//					if(tabuleiro[i-1][j-1]!="")
//						return false;
//				}
//				if (j!=14)
//				{
//					if(tabuleiro[i-1][j+1]!="")
//						return false;
//				}
//			}
//			
//			if(i!=14)
//			{
//				if(tabuleiro[i+1][j]!="")
//					return false;
//				if (j!=14)
//				{
//					if(tabuleiro[i+1][j+1]!="")
//						return false;
//				}
//				if (j!=0)
//				{
//					if(tabuleiro[i+1][j-1]!="")
//						return false;
//				}
//			}
//			if(j!=0)
//			{
//				if(tabuleiro[i][j-1]!="")
//					return false;
//			}
//			if(j!=14)
//			{
//				if(tabuleiro[i][j+1]!="")
//					return false;
//			}
//			
//		}
//		
//		else if(tipoNavioSelecionado == "d")
//		{
//			
//			if(j==14)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+2]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+2]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+2]!="")
//						return false;
//				}
//			}
//		}
//			
//		else if(tipoNavioSelecionado == "cr")
//		{
//			
//			if(j>11)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+4]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+4]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+4]!="")
//						return false;
//				}
//			}
//		}
//		
//		else if(tipoNavioSelecionado == "co")
//		{
//			System.out.println("ue");
//			if(j>10)
//				return false;
//			else 
//			{
//				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="" || tabuleiro[i][j+4]!="")
//					return false;
//				
//				if(i!=0)
//				{
//					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="" || tabuleiro[i-1][j+4]!="")
//						return false;
//					if (j!=0)
//					{
//						if(tabuleiro[i-1][j-1]!="")
//							return false;
//					}
//					if (j!=14)
//					{
//						if(tabuleiro[i-1][j+5]!="")
//							return false;
//					}
//				}
//				
//				if(i!=14)
//				{
//					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="" || tabuleiro[i+1][j+4]!="")
//						return false;
//					if (j!=14)
//					{
//						if(tabuleiro[i+1][j+5]!="")
//							return false;
//					}
//					if (j!=0)
//					{
//						if(tabuleiro[i+1][j-1]!="")
//							return false;
//					}
//				}
//				if(j!=0)
//				{
//					if(tabuleiro[i][j-1]!="")
//						return false;
//				}
//				if(j!=14)
//				{
//					if(tabuleiro[i][j+5]!="")
//						return false;
//				}
//			}
//		}
//		return true;
//			
//	}
//	
	
}


