package regras;

public class CtrlRegras {
	Arma[][] matrizTabuleiro = new Arma[15][15];
	Arma[][] matrizPecasAEscolher = new Arma[14][19]; 
	private Arma listaArmas[] = new Arma[15];
	private int numArmas = 0;
	private Arma armaSelecionada=null;
	
	public CtrlRegras() 
	{
		int i;
		Arma[] hidroavioes = new Arma[5];
		Arma[] submarinos = new Arma[4];
		Arma[] destroyers = new Arma[3];
		Arma[] cruzadores = new Arma[2];
		Arma couracado;
		
		for(i=0;i< 15;i++)
		{
			matrizTabuleiro[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		for(i=0;i< 13;i++)
		{
			matrizPecasAEscolher[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		
		for(int cont = 0;cont< 5; cont ++)
		{
			int[] coords = {1,cont*4};
			hidroavioes[cont]=new Arma("h",coords);
		}
		
		for(int cont = 0;cont< 4; cont ++)
		{
			int[] coords = {4,cont*2};
			submarinos[cont]=new Arma("s",coords);
		}
		
		for(int cont = 0;cont< 3; cont ++)
		{
			int[] coords = {7,cont*3};
			destroyers[cont]=new Arma("d",coords);
		}
		
		for(int cont = 0;cont< 2; cont ++)
		{
			int[] coords = {10,cont*5};
			cruzadores[cont]=new Arma("cr",coords);
		}
		
		int [] coords = {13,0};
		couracado = new Arma("co",coords);
		
		matrizPecasAEscolher[0] = new Arma[]{null,hidroavioes[0],null,null,null,hidroavioes[1],null,null,null,hidroavioes[2],null,null,null,hidroavioes[3],null,null,null,hidroavioes[4],null};
		
		matrizPecasAEscolher[1] = new Arma[]{hidroavioes[0],null,hidroavioes[0],null,hidroavioes[1],null,hidroavioes[1],null,hidroavioes[2],null,hidroavioes[2],null,hidroavioes[3],null,hidroavioes[3],null,hidroavioes[4],null,hidroavioes[4]};
		
		matrizPecasAEscolher[4] = new Arma[]{submarinos[0],null,submarinos[1],null,submarinos[2],null,submarinos[3],null,null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[7] = new Arma[]{destroyers[0],destroyers[0],null,destroyers[1],destroyers[1],null,destroyers[2],destroyers[2],null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[10] = new Arma[]{cruzadores[0],cruzadores[0],cruzadores[0],cruzadores[0],null,cruzadores[1],cruzadores[1],cruzadores[1],cruzadores[1],null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[13] = new Arma[]{couracado,couracado,couracado,couracado,couracado,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
	}
		
		
	
	public Arma[][] getMatrizTabuleiro() {
		return matrizTabuleiro;
	}
	
	public Arma[][] getMatrizPecasAEscolher() {
		return matrizPecasAEscolher;
	}
	
	
	public void reiniciar()
	{
		/*
		 * int i,j; vez=1; numJogadas =1; for(i = 0;i < 3;i++) { for(j = 0; j <3;j++) {
		 * matrizTabuleiro[i][j]=0; } }
		 */
	}
	

	public void deselecionaNavio()
	{
		if(armaSelecionada!=null)
			armaSelecionada.alterarStatusArma(false);
		armaSelecionada = null;
	}
	
	public void moverArma(Arma armaSelecionada,int i,int j)
	{
		boolean possivelInserir = testaPossivelInserir(i,j);
		//debug(possivelInserir);
		int linha;
		if(possivelInserir == true)
		{
			
			int [][] casasArma = armaSelecionada.getCasas();
			
			if(!armaSelecionada.foiInserida())
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
					matrizPecasAEscolher[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
				armaSelecionada.tornarInserida();
				listaArmas[numArmas] = armaSelecionada;
				numArmas++;
				
			}
			else
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
					matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
			}
			armaSelecionada.setCoordenadas(i,j);
			casasArma = armaSelecionada.getCasas();
			for(linha = 0;linha<casasArma.length;linha++)
			{
				matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = armaSelecionada;
			}
		}
	}
	
	private boolean testaPossivelInserir(int i,int j)
	{
		boolean armaEncaixaTabuleiro = armaSelecionada.testaEncaixaTabuleiro(i,j);
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
//		else
//		{
//			for (int cont = 0;cont<listaArmas.length;cont++)
//			{
//				Arma armaAtual = listaArmas[cont];
//				armaNaoCompartilhaVerticeVizinho = armaSelecionada.testaProximidadeVizinho(armaAtual);
//				if(!armaNaoCompartilhaVerticeVizinho)
//					return false;
//			}
//		}
		return true;
		
	}

	private boolean testaPossivelInserir()
	{
		boolean armaEncaixaTabuleiro = armaSelecionada.testaEncaixaTabuleiro();
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
//		else
//		{
//			for (int cont = 0;cont<listaArmas.length;cont++)
//			{
//				Arma armaAtual = listaArmas[cont];
//				armaNaoCompartilhaVerticeVizinho = armaSelecionada.testaProximidadeVizinho(armaAtual);
//				if(!armaNaoCompartilhaVerticeVizinho)
//					return false;
//			}
//		}
		return true;
		
	}
	

	public void selecionarArma(String pos,int i, int j) 
	{
		Arma armaEscolhida;
		if(pos=="esq")
			armaEscolhida= matrizPecasAEscolher[i][j];
		else
		{
			armaEscolhida = matrizTabuleiro[i][j];
			if(armaEscolhida == null && armaSelecionada != null)
			{
				moverArma(armaSelecionada,i,j);
			}
		}
		if(armaEscolhida != null)
		{
			if(armaSelecionada!=null)
				armaSelecionada.alterarStatusArma(false);
			armaSelecionada = armaEscolhida;
			armaEscolhida.alterarStatusArma(true);
		}
	}
	
	
	public void rotacionarArma() 
	{
		
		if(armaSelecionada!=null && armaSelecionada.foiInserida())
		{
			
			int linha;
			int [][] casasArmaAnterior = armaSelecionada.getCasas();
			armaSelecionada.alterarDirecaoNoventaGraus(true);
			boolean possivelInserir = testaPossivelInserir();// TROCAR
			if(possivelInserir)
			{
				for(linha = 0;linha<casasArmaAnterior.length;linha++)
				{
					matrizTabuleiro[casasArmaAnterior[linha][0]][casasArmaAnterior[linha][1]] = null;
				}
				int [][] casasArmaAtual = armaSelecionada.getCasas();
				for(linha = 0;linha<casasArmaAtual.length;linha++)
				{
					matrizTabuleiro[casasArmaAtual[linha][0]][casasArmaAtual[linha][1]] = armaSelecionada;
				}
			}
			else
			{
				armaSelecionada.alterarDirecaoNoventaGraus(false);
			}
			
		}
	}
	
	//DEBUG-TIRAR DPS
	private void debug(boolean possivelInserir)
	{
		System.out.println(possivelInserir);
	}
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
}
