package regras;

public class CtrlRegras {
	Arma[][] matrizTabuleiro = new Arma[15][15];
	Arma[][] matrizPecasAEscolher = new Arma[14][19]; 
	private int posNavioSelecionado= -1;
	private String tipoNavioSelecionado = "";
	private boolean navioInserido = false;
	private Arma listaArmas[] = new Arma[15];
	private int numArmas = 0;
	private Arma armaSelecionada=null;
	
	public CtrlRegras() 
	{
		int i;
		Arma[] hidroavioes = new Arma[5];
		Arma[] submarinos = new Arma[4];
		Arma[] destroyers = new Arma[3];
		Arma[] cruzadores = new Arma[2];
		Arma couracado;
		
		for(i=0;i< 15;i++)
		{
			matrizTabuleiro[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		for(i=0;i< 13;i++)
		{
			matrizPecasAEscolher[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		
		for(int cont = 0;cont< 5; cont ++)
		{
			int[] coords = {1,cont*4+1};
			hidroavioes[cont]=new Arma("h",coords);
		}
		
		for(int cont = 0;cont< 4; cont ++)
		{
			int[] coords = {4,cont*2};
			submarinos[cont]=new Arma("s",coords);
		}
		
		for(int cont = 0;cont< 3; cont ++)
		{
			int[] coords = {7,cont*3};
			destroyers[cont]=new Arma("d",coords);
		}
		
		for(int cont = 0;cont< 2; cont ++)
		{
			int[] coords = {10,cont*5};
			cruzadores[cont]=new Arma("cr",coords);
		}
		
		int [] coords = {13,0};
		couracado = new Arma("co",coords);
		
		matrizPecasAEscolher[0] = new Arma[]{null,hidroavioes[0],null,null,null,hidroavioes[1],null,null,null,hidroavioes[2],null,null,null,hidroavioes[3],null,null,null,hidroavioes[4],null};
		matrizPecasAEscolher[1] = new Arma[]{hidroavioes[0],null,hidroavioes[0],null,hidroavioes[1],null,hidroavioes[1],null,hidroavioes[2],null,hidroavioes[2],null,hidroavioes[3],null,hidroavioes[3],null,hidroavioes[4],null,hidroavioes[4]};
		matrizPecasAEscolher[4] = new Arma[]{submarinos[0],null,submarinos[1],null,submarinos[2],null,submarinos[3],null,null,null,null,null,null,null,null,null,null,null,null};
		matrizPecasAEscolher[7] = new Arma[]{destroyers[0],destroyers[0],null,destroyers[1],destroyers[1],null,destroyers[2],destroyers[2],null,null,null,null,null,null,null,null,null,null,null};
		matrizPecasAEscolher[10] = new Arma[]{cruzadores[0],cruzadores[0],cruzadores[0],cruzadores[0],null,cruzadores[1],cruzadores[1],cruzadores[1],cruzadores[1],null,null,null,null,null,null,null,null,null,null};
		matrizPecasAEscolher[13] = new Arma[]{couracado,couracado,couracado,couracado,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
	}
		
		
	
	public Arma[][] getMatrizTabuleiro() {
		return matrizTabuleiro;
	}
	
	public Arma[][] getMatrizPecasAEscolher() {
		return matrizPecasAEscolher;
	}
	
	
	public void reiniciar()
	{
		/*
		 * int i,j; vez=1; numJogadas =1; for(i = 0;i < 3;i++) { for(j = 0; j <3;j++) {
		 * matrizTabuleiro[i][j]=0; } }
		 */
	}
	
//	public int detectarVencedor()
//	{
//		
//		
//	}
	
//	public boolean verificaNavioSelecionado(int i,int j)
//	{
//		int cont;
//		String armaSelecionada = matrizPecasAEscolher[i][j];
//		if(armaSelecionada == "h")
//		{
//			deselecionaNavio();
//			posNavioSelecionado = j/4;
//			tipoNavioSelecionado = "h";
//			matrizPecasAEscolher[1][posNavioSelecionado*4] = matrizPecasAEscolher[0][posNavioSelecionado*4+1] = matrizPecasAEscolher[1][posNavioSelecionado*4+2]= "S";
//		}
//		
//		else if(armaSelecionada == "s")
//		{
//			deselecionaNavio();
//			posNavioSelecionado= j/2;
//			tipoNavioSelecionado = "s";
//			matrizPecasAEscolher[i][j]="S";
//		}
//		else if(armaSelecionada == "d")
//		{
//			deselecionaNavio();
//			posNavioSelecionado= j/3;
//			tipoNavioSelecionado = "d";
//			matrizPecasAEscolher[i][posNavioSelecionado*3]=matrizPecasAEscolher[i][posNavioSelecionado*3+1]="S";
//		}
//		else if(armaSelecionada == "cr")
//		{
//				deselecionaNavio();
//				posNavioSelecionado= j/5;
//				tipoNavioSelecionado = "cr";
//				matrizPecasAEscolher[i][posNavioSelecionado*5]=matrizPecasAEscolher[i][posNavioSelecionado*5+1]=matrizPecasAEscolher[i][posNavioSelecionado*5+2]=matrizPecasAEscolher[i][posNavioSelecionado*5+3]="S";
//		}
//		
//		else if(armaSelecionada == "co")
//		{
//
//			deselecionaNavio();
//			posNavioSelecionado= 0;
//			tipoNavioSelecionado = "co";
//			for(cont = 0;cont < 5; cont++)
//				matrizPecasAEscolher[i][cont]="S";
//		}
//		else
//			return false;
//		return true;
//	}
//	
//	public void deselecionaNavio()
//	{
//		int cont;
//		if(tipoNavioSelecionado == "h")
//		{
//			matrizPecasAEscolher[0][posNavioSelecionado*4+1]=matrizPecasAEscolher[1][posNavioSelecionado*4]=matrizPecasAEscolher[1][posNavioSelecionado*4+2]="h";
//		}
//		
//		else if(tipoNavioSelecionado == "s")
//		{
//			matrizPecasAEscolher[4][posNavioSelecionado*2]="s";
//		}
//		
//		else if(tipoNavioSelecionado == "d")
//		{
//			matrizPecasAEscolher[7][posNavioSelecionado*3]=matrizPecasAEscolher[7][posNavioSelecionado*3+1]="d";
//		}
//		else if(tipoNavioSelecionado == "cr")
//		{
//			for(cont = 0;cont < 4; cont++)
//				matrizPecasAEscolher[10][5*posNavioSelecionado+cont]="cr";
//		}
//		else if(tipoNavioSelecionado == "co")
//		{
//			for(cont = 0;cont < 5; cont++)
//				matrizPecasAEscolher[13][cont]="co";
//		}
//		posNavioSelecionado = -1;
//		tipoNavioSelecionado = "";
//		if(armaSelecionada!=null)
//			armaSelecionada.alterarStatusArma(false);
//	}
//	
//	public boolean existeArmaNaoPosicionadaSelecionada()
//	{
//		if(tipoNavioSelecionado == "")
//			return false;
//		return true;
//	}
//	
//	public boolean insereNaviomatrizTabuleiro(int i,int j)
//	{
//		boolean possivelInserir = testaPossivelInserir(i,j);
//		System.out.println(possivelInserir);
//		if(possivelInserir == false)
//			return false;
//		else
//		{
//			Arma novaArma = null;
//			int[][] coords;
//			int numCasas;
//			if(tipoNavioSelecionado == "h")
//			{
//				coords = new int[1][2];
//				coords[0][0]=i;
//				coords[0][1]=j+1;
//				novaArma = new Arma(tipoNavioSelecionado,coords);
//				//coords[1][0]=i;
//				//coords[1][1]=j;
//				//coords[2][0]=i;
//				//coords[2][1]=j;
//				matrizTabuleiro[i][j] = matrizTabuleiro[i-1][j+1] = matrizTabuleiro[i][j+2] = novaArma;
//			}
//			else if(tipoNavioSelecionado == "s")
//			{
//				coords = new int[1][2];
//				coords[0][0]=i;
//				coords[0][1]=j;
//				novaArma = new Arma(tipoNavioSelecionado,coords);
//				matrizTabuleiro[i][j] = novaArma;
//	
//
////				int a[][]=listaArmas[0].getCoordX();
////				System.out.println(a[0]);
////				System.out.println(a[0][0]);
////				System.out.println(a[0][1]);
//				//System.out.println(a[1]);
//				
//			}
//			else if(tipoNavioSelecionado == "d")
//			{
//				coords = new int[1][2];
//				coords[0][0]=i;
//				coords[0][1]=j;
//				novaArma = new Arma(tipoNavioSelecionado,coords);
//				matrizTabuleiro[i][j] = matrizTabuleiro[i][j+1] =novaArma;
//				//coords = new int[1][2];
//				//matrizTabuleiro[i][j] = matrizTabuleiro[i][j+1] ="d";
//			}
//			else if(tipoNavioSelecionado == "cr")
//			{
//				coords = new int[1][2];
//				coords[0][0]=i;
//				coords[0][1]=j;
//				novaArma = new Arma(tipoNavioSelecionado,coords);
//				matrizTabuleiro[i][j] = matrizTabuleiro[i][j+1] = matrizTabuleiro[i][j+2] = matrizTabuleiro[i][j+3] =novaArma;
//			}
//			else if(tipoNavioSelecionado == "co")
//			{
//				coords = new int[1][2];
//				coords[0][0]=i;
//				coords[0][1]=j;
//				novaArma = new Arma(tipoNavioSelecionado,coords);
//				matrizTabuleiro[i][j] = matrizTabuleiro[i][j+1] = matrizTabuleiro[i][j+2] = matrizTabuleiro[i][j+3] = matrizTabuleiro[i][j+4] = novaArma;
//			}
//			listaArmas[numArmas] = novaArma;
//			numArmas++;
//			
//		}
//		return true;
//		
//	}
	
	private boolean testaPossivelInserir(int i,int j)
	{
		//testar vizinhos
		if(tipoNavioSelecionado == "h")
		{
			if(j>12 || i == 0)
				return false;
		}
		
		else if(tipoNavioSelecionado == "d")
		{
			if(j>13)
				return false;
		}
		else if(tipoNavioSelecionado == "cr")
		{
			if(j>11)
				return false;
		}
		else if(tipoNavioSelecionado == "co")
		{
			if(j>10)
				return false;
		}
		return true;
	}



	public void selecionaNavioTabuleiro(String pos,int i, int j) 
	{
		Arma arma;
		if(pos=="esq")
			arma= matrizPecasAEscolher[i][j];
		else
			arma = matrizTabuleiro[i][j];
		if(arma != null)
		{
			if(armaSelecionada!=null)
				armaSelecionada.alterarStatusArma(false);
			armaSelecionada = arma;
			arma.alterarStatusArma(true);
		}
	}
	
	
	
	
}
