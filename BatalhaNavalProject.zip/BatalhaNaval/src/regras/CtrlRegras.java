package regras;

public class CtrlRegras {
	Arma[][] tabuleiro = new Arma[15][15];
	String[][] matrizNavios = new String[14][19]; 
	private int posNavioSelecionado= -1;
	private String tipoNavioSelecionado = "";
	private boolean navioInserido = false;
	private Arma listaArmas[] = new Arma[15];
	private int numArmas = 0;
	private Arma armaSelecionada=null;
	
	public CtrlRegras() 
	{
		int i;
		for(i=0;i< 15;i++)
		{
			tabuleiro[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		for(i=0;i< 13;i++)
		{
			matrizNavios[i] = new String[]{"","","","","","","","","","","","","","","","","","",""};
		}
		
		matrizNavios[0] = new String[]{"","h","","","","h","","","","h","","","","h","","","","h",""};
		matrizNavios[1] = new String[]{"h","","h","","h","","h","","h","","h","","h","","h","","h","","h",""};
		matrizNavios[4] = new String[]{"s","","s","","s","","s","","","","","","","","","","","",""};
		matrizNavios[7] = new String[]{"d","d","","d","d","","d","d","","","","","","","","","","",""};
		matrizNavios[10] = new String[]{"cr","cr","cr","cr","","cr","cr","cr","cr","","","","","","","","","",""};
		matrizNavios[13] = new String[]{"co","co","co","co","co","","","","","","","","","","","","","",""};
	}
		
		
	
	public Arma[][] getTabuleiro() {
		return tabuleiro;
	}
	
	public String[][] getmatrizNavios() {
		return matrizNavios;
	}
	
	
	public void reiniciar()
	{
		/*
		 * int i,j; vez=1; numJogadas =1; for(i = 0;i < 3;i++) { for(j = 0; j <3;j++) {
		 * tabuleiro[i][j]=0; } }
		 */
	}
	
//	public int detectarVencedor()
//	{
//		
//		
//	}
	
	public boolean verificaNavioSelecionado(int i,int j)
	{
		int cont;
		String armaSelecionada = matrizNavios[i][j];
		if(armaSelecionada == "h")
		{
			deselecionaNavio();
			posNavioSelecionado = j/4;
			tipoNavioSelecionado = "h";
			matrizNavios[1][posNavioSelecionado*4] = matrizNavios[0][posNavioSelecionado*4+1] = matrizNavios[1][posNavioSelecionado*4+2]= "S";
		}
		
		else if(armaSelecionada == "s")
		{
			deselecionaNavio();
			posNavioSelecionado= j/2;
			tipoNavioSelecionado = "s";
			matrizNavios[i][j]="S";
		}
		else if(armaSelecionada == "d")
		{
			deselecionaNavio();
			posNavioSelecionado= j/3;
			tipoNavioSelecionado = "d";
			matrizNavios[i][posNavioSelecionado*3]=matrizNavios[i][posNavioSelecionado*3+1]="S";
		}
		else if(armaSelecionada == "cr")
		{
				deselecionaNavio();
				posNavioSelecionado= j/5;
				tipoNavioSelecionado = "cr";
				matrizNavios[i][posNavioSelecionado*5]=matrizNavios[i][posNavioSelecionado*5+1]=matrizNavios[i][posNavioSelecionado*5+2]=matrizNavios[i][posNavioSelecionado*5+3]="S";
		}
		
		else if(armaSelecionada == "co")
		{

			deselecionaNavio();
			posNavioSelecionado= 0;
			tipoNavioSelecionado = "co";
			for(cont = 0;cont < 5; cont++)
				matrizNavios[i][cont]="S";
		}
		else
			return false;
		return true;
	}
	
	public void deselecionaNavio()
	{
		int cont;
		if(tipoNavioSelecionado == "h")
		{
			matrizNavios[0][posNavioSelecionado*4+1]=matrizNavios[1][posNavioSelecionado*4]=matrizNavios[1][posNavioSelecionado*4+2]="h";
		}
		
		else if(tipoNavioSelecionado == "s")
		{
			matrizNavios[4][posNavioSelecionado*2]="s";
		}
		
		else if(tipoNavioSelecionado == "d")
		{
			matrizNavios[7][posNavioSelecionado*3]=matrizNavios[7][posNavioSelecionado*3+1]="d";
		}
		else if(tipoNavioSelecionado == "cr")
		{
			for(cont = 0;cont < 4; cont++)
				matrizNavios[10][5*posNavioSelecionado+cont]="cr";
		}
		else if(tipoNavioSelecionado == "co")
		{
			for(cont = 0;cont < 5; cont++)
				matrizNavios[13][cont]="co";
		}
		posNavioSelecionado = -1;
		tipoNavioSelecionado = "";
		if(armaSelecionada!=null)
			armaSelecionada.alterarStatusArma(false);
	}
	
	public boolean existeArmaNaoPosicionadaSelecionada()
	{
		if(tipoNavioSelecionado == "")
			return false;
		return true;
	}
	
	public boolean insereNavioTabuleiro(int i,int j)
	{
		boolean possivelInserir = testaPossivelInserir(i,j);
		System.out.println(possivelInserir);
		if(possivelInserir == false)
			return false;
		else
		{
			Arma novaArma = null;
			int[][] coords;
			int numCasas;
			if(tipoNavioSelecionado == "h")
			{
				coords = new int[1][2];
				coords[0][0]=i;
				coords[0][1]=j+1;
				novaArma = new Arma(tipoNavioSelecionado,coords);
				//coords[1][0]=i;
				//coords[1][1]=j;
				//coords[2][0]=i;
				//coords[2][1]=j;
				tabuleiro[i][j] = tabuleiro[i-1][j+1] = tabuleiro[i][j+2] = novaArma;
			}
			else if(tipoNavioSelecionado == "s")
			{
				coords = new int[1][2];
				coords[0][0]=i;
				coords[0][1]=j;
				novaArma = new Arma(tipoNavioSelecionado,coords);
				tabuleiro[i][j] = novaArma;
	

//				int a[][]=listaArmas[0].getCoordX();
//				System.out.println(a[0]);
//				System.out.println(a[0][0]);
//				System.out.println(a[0][1]);
				//System.out.println(a[1]);
				
			}
			else if(tipoNavioSelecionado == "d")
			{
				coords = new int[1][2];
				coords[0][0]=i;
				coords[0][1]=j;
				novaArma = new Arma(tipoNavioSelecionado,coords);
				tabuleiro[i][j] = tabuleiro[i][j+1] =novaArma;
				//coords = new int[1][2];
				//tabuleiro[i][j] = tabuleiro[i][j+1] ="d";
			}
			else if(tipoNavioSelecionado == "cr")
			{
				coords = new int[1][2];
				coords[0][0]=i;
				coords[0][1]=j;
				novaArma = new Arma(tipoNavioSelecionado,coords);
				tabuleiro[i][j] = tabuleiro[i][j+1] = tabuleiro[i][j+2] = tabuleiro[i][j+3] =novaArma;
			}
			else if(tipoNavioSelecionado == "co")
			{
				coords = new int[1][2];
				coords[0][0]=i;
				coords[0][1]=j;
				novaArma = new Arma(tipoNavioSelecionado,coords);
				tabuleiro[i][j] = tabuleiro[i][j+1] = tabuleiro[i][j+2] = tabuleiro[i][j+3] = tabuleiro[i][j+4] = novaArma;
			}
			listaArmas[numArmas] = novaArma;
			numArmas++;
			
		}
		return true;
		
	}
	
	private boolean testaPossivelInserir(int i,int j)
	{
		//testar vizinhos
		if(tipoNavioSelecionado == "h")
		{
			if(j>12 || i == 0)
				return false;
		}
		
		else if(tipoNavioSelecionado == "d")
		{
			if(j>13)
				return false;
		}
		else if(tipoNavioSelecionado == "cr")
		{
			if(j>11)
				return false;
		}
		else if(tipoNavioSelecionado == "co")
		{
			if(j>10)
				return false;
		}
		return true;
	}



	public void selecionaNavioTabuleiro(int i, int j) 
	{
		Arma arma = tabuleiro[i][j];
		if(arma != null)
		{
			if(armaSelecionada!=null)
				armaSelecionada.alterarStatusArma(false);
			armaSelecionada = arma;
			arma.alterarStatusArma(true);
		}
	}
	
	
	
	
}
