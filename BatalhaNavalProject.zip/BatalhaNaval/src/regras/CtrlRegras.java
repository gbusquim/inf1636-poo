package regras;

public class CtrlRegras {
	String[][] tabuleiro = new String[15][15];
	String[][] matrizNavios = new String[14][19]; 
	private int posNavioSelecionado= -1;
	private String tipoNavioSelecionado = "";
	private boolean navioInserido = false;
	
	public CtrlRegras() 
	{
		int i;
		for(i=0;i< 15;i++)
		{
			tabuleiro[i] = new String[]{"","","","","","","","","","","","","","","","","","",""};
		}
		for(i=0;i< 13;i++)
		{
			matrizNavios[i] = new String[]{"","","","","","","","","","","","","","","","","","",""};
		}
		
		matrizNavios[0] = new String[]{"","h","","","","h","","","","h","","","","h","","","","h",""};
		matrizNavios[1] = new String[]{"h","","h","","h","","h","","h","","h","","h","","h","","h","","h",""};
		matrizNavios[4] = new String[]{"s","","s","","s","","s","","","","","","","","","","","",""};
		matrizNavios[7] = new String[]{"d","d","","d","d","","d","d","","","","","","","","","","",""};
		matrizNavios[10] = new String[]{"cr","cr","cr","cr","","cr","cr","cr","cr","","","","","","","","","",""};
		matrizNavios[13] = new String[]{"co","co","co","co","co","","","","","","","","","","","","","",""};
	}
		
		
	
	public String[][] getTabuleiro() {
		return tabuleiro;
	}
	
	public String[][] getmatrizNavios() {
		return matrizNavios;
	}
	
	
	public void reiniciar()
	{
		/*
		 * int i,j; vez=1; numJogadas =1; for(i = 0;i < 3;i++) { for(j = 0; j <3;j++) {
		 * tabuleiro[i][j]=0; } }
		 */
	}
	
//	public int detectarVencedor()
//	{
//		
//		
//	}
	
	public boolean verificaNavioSelecionado(int i,int j)
	{
		int cont;
		if(i ==1 || i == 0)
		{
			for(cont = 1;cont<18;cont=cont+4)
			{
				if((i == 1 && (j==cont -1 || j==cont +1)) || i == 0 && j==cont)
				{
					deselecionaNavio();
					posNavioSelecionado= cont/4;
					tipoNavioSelecionado = "h";
					matrizNavios[0][cont]=matrizNavios[1][cont -1]=matrizNavios[1][cont +1]="S";
					break;
				}
			}
		}
		else if(i ==4 && (j == 0 || j == 2 || j == 4 || j == 6))
		{
				deselecionaNavio();
				posNavioSelecionado= j/2;
				tipoNavioSelecionado = "s";
				matrizNavios[i][j]="S";
		}
		else if(i ==7)
		{
			for(cont = 0;cont<7;cont=cont+3)
			{
				if(j== cont || j==cont + 1)
				{
					deselecionaNavio();
					posNavioSelecionado= cont/3;
					tipoNavioSelecionado = "d";
					matrizNavios[i][cont]=matrizNavios[i][cont +1]="S";
					break;
				}
			}
			
		}
		
		else if(i == 10)
		{
			if(j < 4)
			{
				deselecionaNavio();
				posNavioSelecionado= 0;
				tipoNavioSelecionado = "cr";
				for(cont = 0;cont < 4; cont++)
					matrizNavios[i][cont]="S";
			}
			else if(j < 9 && j!=4)
			{
				deselecionaNavio();
				posNavioSelecionado= 1;
				tipoNavioSelecionado = "cr";
				for(cont = 5;cont < 9; cont++)
					matrizNavios[i][cont]="S";
			}
		}
		
		else if(i == 13)
		{
			if(j < 5)
			{
				deselecionaNavio();
				posNavioSelecionado= 0;
				tipoNavioSelecionado = "co";
				for(cont = 0;cont < 5; cont++)
					matrizNavios[i][cont]="S";
			}
		}
		else
			return false;
		return true;
	}
	
	public void deselecionaNavio()
	{
		int cont;
		if(tipoNavioSelecionado == "h")
		{
			matrizNavios[0][posNavioSelecionado*4+1]=matrizNavios[1][posNavioSelecionado*4]=matrizNavios[1][posNavioSelecionado*4+2]="h";
		}
		
		else if(tipoNavioSelecionado == "s")
		{
			matrizNavios[4][posNavioSelecionado*2]="s";
		}
		
		else if(tipoNavioSelecionado == "d")
		{
			matrizNavios[7][posNavioSelecionado*3]=matrizNavios[7][posNavioSelecionado*3+1]="d";
		}
		else if(tipoNavioSelecionado == "cr")
		{
			for(cont = 0;cont < 4; cont++)
				matrizNavios[10][5*posNavioSelecionado+cont]="cr";
		}
		else if(tipoNavioSelecionado == "co")
		{
			for(cont = 0;cont < 5; cont++)
				matrizNavios[13][cont]="co";
		}
		posNavioSelecionado = -1;
		tipoNavioSelecionado = "";
	}
	
	public boolean insereNavioTabuleiro(int i,int j)
	{
		boolean possivelInserir = testaPossivelInserir(i,j);
		System.out.println(possivelInserir);
		if(possivelInserir == false)
			return false;
		else
		{
			if(tipoNavioSelecionado == "h")
			{
				tabuleiro[i][j] = tabuleiro[i-1][j+1] = tabuleiro[i][j+2] = "h";
			}
			else if(tipoNavioSelecionado == "s")
			{
				tabuleiro[i][j] = "s";
			}
			else if(tipoNavioSelecionado == "d")
			{
				tabuleiro[i][j] = tabuleiro[i][j+1] ="d";
			}
			else if(tipoNavioSelecionado == "cr")
			{
				tabuleiro[i][j] = tabuleiro[i][j+1] = tabuleiro[i][j+2] = tabuleiro[i][j+3] ="cr";
			}
			else if(tipoNavioSelecionado == "co")
			{
				tabuleiro[i][j] = tabuleiro[i][j+1] = tabuleiro[i][j+2] = tabuleiro[i][j+3] = tabuleiro[i][j+4] = "co";
			}
		}
		return true;
		
	}
	
	private boolean testaPossivelInserir(int i,int j)
	{
		if(tipoNavioSelecionado == "h")
		{
			if(j>12 || i == 0)
			{
				
				return false;
			}
			else
			{
				if(tabuleiro[i][j]!="" || tabuleiro[i-1][j+1] != "" || tabuleiro[i][j+2] != "" )
					return false;
					
				if (tabuleiro[i][j+1] != "" || tabuleiro[i-1][j] != "" || tabuleiro[i-1][j+2] != "")
					return false;

				if(j!=0)
				{
					if(tabuleiro[i][j-1] != "")
						return false;
					
					if(tabuleiro[i-1][j-1] != "")
						return false;
					
					if(i != 14)
					{
						if(tabuleiro[i+1][j-1] != "")
							return false;
					}

				}
				if(j!=14)
				{ 
					if(tabuleiro[i][j+3] != "" || tabuleiro[i-1][j+3] != "")
						return false;
					if(i!=14)
					{
						if(tabuleiro[i+1][j+3] != "" )
							return false;
					}
				}
				if(i>1)
				{
					if(tabuleiro[i-2][j] != "" || tabuleiro[i-2][j+1] != "" || tabuleiro[i-2][j+2] != "")
						return false;
				}
				if(i!=14)
				{
					if(tabuleiro[i+1][j] != "" || tabuleiro[i+1][j+1] != "" || tabuleiro[i+1][j+2] != "")
						return false;
				}
				

			}
		}
		
	
		
		else if(tipoNavioSelecionado == "s")
		{
			if(tabuleiro[i][j]!="")
				return false;
			
			if(i!=0)
			{
				if(tabuleiro[i-1][j]!="")
					return false;
				if (j!=0)
				{
					if(tabuleiro[i-1][j-1]!="")
						return false;
				}
				if (j!=14)
				{
					if(tabuleiro[i-1][j+1]!="")
						return false;
				}
			}
			
			if(i!=14)
			{
				if(tabuleiro[i+1][j]!="")
					return false;
				if (j!=14)
				{
					if(tabuleiro[i+1][j+1]!="")
						return false;
				}
				if (j!=0)
				{
					if(tabuleiro[i+1][j-1]!="")
						return false;
				}
			}
			if(j!=0)
			{
				if(tabuleiro[i][j-1]!="")
					return false;
			}
			if(j!=14)
			{
				if(tabuleiro[i][j+1]!="")
					return false;
			}
			
		}
		
		else if(tipoNavioSelecionado == "d")
		{
			
			if(j==14)
				return false;
			else 
			{
				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="")
					return false;
				
				if(i!=0)
				{
					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="")
						return false;
					if (j!=0)
					{
						if(tabuleiro[i-1][j-1]!="")
							return false;
					}
					if (j!=14)
					{
						if(tabuleiro[i-1][j+2]!="")
							return false;
					}
				}
				
				if(i!=14)
				{
					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="")
						return false;
					if (j!=14)
					{
						if(tabuleiro[i+1][j+2]!="")
							return false;
					}
					if (j!=0)
					{
						if(tabuleiro[i+1][j-1]!="")
							return false;
					}
				}
				if(j!=0)
				{
					if(tabuleiro[i][j-1]!="")
						return false;
				}
				if(j!=14)
				{
					if(tabuleiro[i][j+2]!="")
						return false;
				}
			}
		}
			
		else if(tipoNavioSelecionado == "cr")
		{
			
			if(j>11)
				return false;
			else 
			{
				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="")
					return false;
				
				if(i!=0)
				{
					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="")
						return false;
					if (j!=0)
					{
						if(tabuleiro[i-1][j-1]!="")
							return false;
					}
					if (j!=14)
					{
						if(tabuleiro[i-1][j+4]!="")
							return false;
					}
				}
				
				if(i!=14)
				{
					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="")
						return false;
					if (j!=14)
					{
						if(tabuleiro[i+1][j+4]!="")
							return false;
					}
					if (j!=0)
					{
						if(tabuleiro[i+1][j-1]!="")
							return false;
					}
				}
				if(j!=0)
				{
					if(tabuleiro[i][j-1]!="")
						return false;
				}
				if(j!=14)
				{
					if(tabuleiro[i][j+4]!="")
						return false;
				}
			}
		}
		
		else if(tipoNavioSelecionado == "co")
		{
			System.out.println("ue");
			if(j>10)
				return false;
			else 
			{
				if(tabuleiro[i][j]!="" || tabuleiro[i][j+1]!="" || tabuleiro[i][j+2]!="" || tabuleiro[i][j+3]!="" || tabuleiro[i][j+4]!="")
					return false;
				
				if(i!=0)
				{
					if(tabuleiro[i-1][j]!="" || tabuleiro[i-1][j+1]!="" || tabuleiro[i-1][j+2]!="" || tabuleiro[i-1][j+3]!="" || tabuleiro[i-1][j+4]!="")
						return false;
					if (j!=0)
					{
						if(tabuleiro[i-1][j-1]!="")
							return false;
					}
					if (j!=14)
					{
						if(tabuleiro[i-1][j+5]!="")
							return false;
					}
				}
				
				if(i!=14)
				{
					if(tabuleiro[i+1][j]!="" || tabuleiro[i+1][j+1]!="" || tabuleiro[i+1][j+2]!="" || tabuleiro[i+1][j+3]!="" || tabuleiro[i+1][j+4]!="")
						return false;
					if (j!=14)
					{
						if(tabuleiro[i+1][j+5]!="")
							return false;
					}
					if (j!=0)
					{
						if(tabuleiro[i+1][j-1]!="")
							return false;
					}
				}
				if(j!=0)
				{
					if(tabuleiro[i][j-1]!="")
						return false;
				}
				if(j!=14)
				{
					if(tabuleiro[i][j+5]!="")
						return false;
				}
			}
		}
		return true;
			
	}
	
}
