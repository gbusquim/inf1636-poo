package regras;

public class Fachada {
	private static Fachada fachada=null;
	CtrlRegras ctrl;
	Arma arma;
	
	private Fachada() 
	{
		ctrl=new CtrlRegras();
	}
	
	public static Fachada getFachada() 
	{
	if(fachada==null)
		fachada=new Fachada();
	return fachada;
	}
	
	public String[][] getTabuleiro()
	{
		String[][] matrizTipos = new String[15][15];
		Arma [][] matrizTabuleiro = ctrl.getTabuleiro();
		for(int i=0; i<15; i++)
		{
		  for(int j=0; j<15; j++)
		  {
			  if(matrizTabuleiro[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizTabuleiro[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizTabuleiro[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
		
	}

	public String[][] getmatrizNavios()
	{
		return ctrl.getmatrizNavios();
	}
	
	public boolean verificaNavioSelecionado(int i,int j)
	{
		return ctrl.verificaNavioSelecionado(i,j);
	}
	
	public boolean trataCliqueTabuleiro (int i,int j) // mudar para ctrl fazer tudo l� dentro em uma s� fun��o (se for tudo na mesma classe)
	{
		if(ctrl.existeArmaNaoPosicionadaSelecionada())
			ctrl.insereNavioTabuleiro(i,j);
		else
			ctrl.selecionaNavioTabuleiro(i,j);
		return false;
	}
	
	public boolean insereNavioTabuleiro(int i,int j)
	{
		return ctrl.insereNavioTabuleiro(i,j);
	}
	
	public void deselecionaNavio()
	{
		ctrl.deselecionaNavio();
	}

	

}
