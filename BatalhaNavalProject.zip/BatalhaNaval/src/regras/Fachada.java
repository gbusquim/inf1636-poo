package regras;

public class Fachada {
	private static Fachada fachada=null;
	CtrlRegras ctrl;
	Arma arma;
	
	private Fachada() 
	{
		ctrl=new CtrlRegras();
	}
	
	public static Fachada getFachada() 
	{
	if(fachada==null)
		fachada=new Fachada();
	return fachada;
	}
	
	public String[][] getMatriz(String tipoMatriz)
	{
		String[][] matrizTipos;
		Arma [][] matrizArmas;
		if(tipoMatriz == "tabuleiro")
		{
			matrizTipos = new String[15][15];
			matrizArmas = ctrl.getMatrizTabuleiro();
		}
		else //tratar erro se parametro vier diferente do esperado
		{
			matrizTipos = new String[14][19];
			matrizArmas = ctrl.getMatrizPecasAEscolher();
		}

		for(int i=0; i<matrizArmas.length; i++)
		{
		  for(int j=0; j<matrizArmas[0].length; j++)
		  {
			  if(matrizArmas[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizArmas[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
		
	}
	
	public boolean verificaNavioSelecionado(String pos,int i,int j)
	{
		ctrl.selecionaNavioTabuleiro(pos,i,j);
		return true;
	}
//	
//	public boolean trataCliqueTabuleiro (int i,int j) // mudar para ctrl fazer tudo l� dentro em uma s� fun��o (se for tudo na mesma classe)
//	{
//		if(ctrl.existeArmaNaoPosicionadaSelecionada())
//			ctrl.insereNavioTabuleiro(i,j);
//		else
//			ctrl.selecionaNavioTabuleiro(i,j);
//		return false;
//	}
//	
//	public boolean insereNavioTabuleiro(int i,int j)
//	{
//		return ctrl.insereNavioTabuleiro(i,j);
//	}
//	
//	public void deselecionaNavio()
//	{
//		ctrl.deselecionaNavio();
//	}

	

}
