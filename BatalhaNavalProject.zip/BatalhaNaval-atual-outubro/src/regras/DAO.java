package regras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.JFileChooser;

public class DAO 
{
		private static DAO acessoArquivos = null;
		
		private DAO() 
		{
			
		}
		
		public static DAO getDAO() 
		{
			if (acessoArquivos == null) 
			{
				acessoArquivos = new DAO();
			}
			return acessoArquivos;
		}
		
		public void salvarJogo() 
		{
			
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
			int resultado = fileChooser.showSaveDialog(null);
	        if (resultado == JFileChooser.APPROVE_OPTION) 
	        {
				try
				{
					FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() +".txt");
					fileWriter.write("TotalJogadores\n");
	//			fileWriter.write("\n");
	//			Player p = board.getCurrentPlayer();
	//			int currentPlayer = p.getNumber();
	//			
	//			for (int i = 0; i < playersCount; i++) {
	//                currentPlayer += 1;
	//    			currentPlayer = currentPlayer % board.getPlayers().size();
	//                Player player = board.getPlayers().get(currentPlayer);
	//                int cardsCount = player.getCards().size();
	//                int businessesCount = player.getBusinesses().size();
	//                
	//                fileWriter.write(player.getName() + "\n"); // name
	//                fileWriter.write("Posicao " + player.getPosition() + "\n"); // position
	//                fileWriter.write("Capital " + player.getWealth() + "\n"); // wealth
	//                fileWriter.write("Preso " + player.getIsArrested() + "\n"); // wealth
	//                fileWriter.write("TotalCartas " + cardsCount + "\n");
	//                
	//                for (int j = 0; j < cardsCount; j++) {
	//                	fileWriter.write(player.getCards().get(j).getName() + " ");
	//                }
	//                
	//                fileWriter.write("\n");
	//                fileWriter.write("TotalLote " + businessesCount + "\n");
	//                
	//                for (int j = 0; j < businessesCount; j++) {
	//                	fileWriter.write(player.getBusinesses().get(j).getCardTypeName() + " ");
	//                	if (player.getBusinesses().get(j) instanceof Property) {
	//                		fileWriter.write(((Property) player.getBusinesses().get(j)).getConstructions() + " ");
	//                	} else {
	//                		fileWriter.write("0 ");
	//                	}
	//                	
	//                }
	//               
	//                fileWriter.write("\n");
	//                fileWriter.write("\n");
	//            }
	//            
					fileWriter.close();
				} 
				catch (FileNotFoundException e) 
				{
					e.printStackTrace();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
		    }
		}
		
		
	}
