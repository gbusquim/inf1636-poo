package regras;

import controlador.ControladorJogo;

public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada = null;
	RegrasFaseAtaques ctrlRegrasAtaques;
	ControladorJogo controlador;

	private FachadaFaseAtaques(ControladorJogo controlador) {
		ctrlRegrasAtaques = new RegrasFaseAtaques(controlador.getOponente());
		this.controlador = controlador;

	}

	public static FachadaFaseAtaques getFachada(ControladorJogo controlador) {
		if (fachada == null)
			fachada = new FachadaFaseAtaques(controlador);
		return fachada;
	}

	
	public String [][] getMatrizJogadorAtual()
	{
		Arma [][] matrizJogadorAtual = controlador.getJogadorAtual().getMatrizArmas();
		boolean transicaoTurno = controlador.getTransicao();
		String[][] matrizCores = new String[15][15];
		Arma armaAtual = null;
		for (int i = 0; i < 15; i++) 
		{
			for (int j = 0; j < 15; j++) 
			{
				if (transicaoTurno) 
				{
					matrizCores[i][j] = "transicao";
				} 
				else 
				{
					armaAtual = matrizJogadorAtual[i][j];
					if (armaAtual == null)
						matrizCores[i][j] = "espa�oVazio";
					else 
					{
						if (armaAtual.foiDestruida())
							matrizCores[i][j] = "destruida";
						else if (armaAtual.verificarCasasDestruidas(i, j) == true)
							matrizCores[i][j] = "casaDestruida";
						else
							matrizCores[i][j] = armaAtual.getTipo();
					}

				}
			}
		}
		return matrizCores;
	}
	
	public String [][] getMatrizOponente(Jogador oponente)
	{
		Arma [][] matrizOponente = oponente.getMatrizArmas();
		boolean transicaoTurno = controlador.getTransicao();
		String[][] matrizCores = new String[15][15];
		Arma armaAtual = null;
		for (int i = 0; i < 15; i++) 
		{
			for (int j = 0; j < 15; j++) 
			{
				if (transicaoTurno) 
				{
					matrizCores[i][j] = "transicao";
				} 
				else 
				{
					armaAtual = matrizOponente[i][j];
					if(oponente.verificarTiroAgua(i, j) == true)
						matrizCores[i][j] = "tiroAgua";
					if(armaAtual != null)
					{
						if (armaAtual.foiDestruida())
							matrizCores[i][j] = "destruida";
						else if(armaAtual.verificarCasasDestruidas(i, j) == true)
							matrizCores[i][j] = "casaDestruida";
					}
					
					
				}
			}
		}

		return matrizCores;
		
		
	}
	
//	public String[][] getMatriz(String tipoMatriz) {
//		// pegar momentoDoJogo -> controlador.getPasso;
//		boolean transicaoTurno = controlador.getTransicao();
//		// Se momento do jogo for standby->TudoAzul
//		String[][] matrizCores = new String[15][15];
//		Arma[][] matrizArmas = null;
//		Arma armaAtual = null;
//
//		for (int i = 0; i < 15; i++) 
//		{
//			for (int j = 0; j < 15; j++) 
//			{
//				if (transicaoTurno) 
//				{
//					matrizCores[i][j] = "transicao";
//				} 
//				else 
//				{
//					if (tipoMatriz == "jogadorAtual")
//					{
//						matrizArmas = controlador.getJogadorAtual().getMatrizArmas();
//						armaAtual = matrizArmas[i][j];
//						if (armaAtual == null)
//							matrizCores[i][j] = "espa�oVazio";
//						else 
//						{
//							if (armaAtual.foiDestruida())
//								matrizCores[i][j] = "destruida";
//							else if (armaAtual.verificarCasasDestruidas(i, j) == true)
//								matrizCores[i][j] = "casaDestruida";
//							else
//								matrizCores[i][j] = armaAtual.getTipo();
//						}
//					}
//					else if (tipoMatriz == "oponente")
//					{
//						matrizArmas = controlador.getOponente().getMatrizArmas();
//						armaAtual = matrizArmas[i][j];
//						if(controlador.getOponente().verificarTiroAgua(i, j) == true)
//							matrizCores[i][j] = "tiroAgua";
//						if(armaAtual != null)
//						{
//							if (armaAtual.foiDestruida())
//								matrizCores[i][j] = "destruida";
//							else if(armaAtual.verificarCasasDestruidas(i, j) == true)
//								matrizCores[i][j] = "casaDestruida";
//						}
//						
//						
//					}
//				}
//			}
//		}
//
//		return matrizCores;
//	}

	 
	
	  public void verificarCasaSelecionada(int i,int j) 
	  {
		  if(!controlador.getTransicao())
			  ctrlRegrasAtaques.verificarCasaSelecionada(i,j);
	  }
	 
	  
	  public String getNomeJogadorAtual()
	  {
		  return controlador.getJogadorAtual().getNome();
	  }
	  
	  public String getNomeOponente()
	  {
		  return controlador.getOponente().getNome();
	  }

	  public void mudarVez()
	  {
		  controlador.mudarVezFaseAtaques();
		  if(!controlador.getTransicao())
			  ctrlRegrasAtaques.novoTurno(controlador.getOponente());
	  }


		public void registrar(Observer observer)
		{
			ctrlRegrasAtaques.addObserver(observer);
		}

		public String definirMensagem(String mensagem) {
			if(controlador.getTransicao())
				return "Vez de " +controlador.getJogadorAtual().getNome();
			else
				return mensagem;
			
		}



}
