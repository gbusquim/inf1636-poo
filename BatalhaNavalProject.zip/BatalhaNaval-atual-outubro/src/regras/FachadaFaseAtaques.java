package regras;

import controlador.ControladorJogo;

public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada = null;
	private static RegrasFaseAtaques ctrlRegrasAtaques;
	private static ControladorJogo controlador;

	private FachadaFaseAtaques(Jogador oponente) {
		ctrlRegrasAtaques = new RegrasFaseAtaques(oponente);
	}

	public static FachadaFaseAtaques getFachada(ControladorJogo controladorJogo)
	{
		controlador = controladorJogo;
		if (fachada == null)
			fachada = new FachadaFaseAtaques(controlador.getOponente());
		else
			ctrlRegrasAtaques.novoJogo(controlador.getOponente());
		return fachada;
	}

	
	public String [][] getMatrizJogadorAtual()
	{
		Jogador jogadorAtual = controlador.getJogadorAtual();
		Arma [][] matrizJogadorAtual = jogadorAtual.getMatrizArmas();
		boolean transicaoTurno = controlador.getTransicao();
		String[][] matrizCores = new String[15][15];
		Arma armaAtual = null;
		for (int i = 0; i < 15; i++) 
		{
			for (int j = 0; j < 15; j++) 
			{
				if (transicaoTurno) 
				{
					matrizCores[i][j] = "transicao";
				} 
				else 
				{
					armaAtual = matrizJogadorAtual[i][j];
					if (armaAtual == null)
					{
						if(jogadorAtual.verificarTiroAgua(i, j) == true)
							matrizCores[i][j] = "tiroAgua";
						else
							matrizCores[i][j] = "espa�oVazio";
					}
						
					else 
					{
						if (armaAtual.foiDestruida())
							matrizCores[i][j] = "destruida";
						else if (armaAtual.verificarCasasDestruidas(i, j) == true)
							matrizCores[i][j] = "casaDestruida";
						else
							matrizCores[i][j] = armaAtual.getTipo();
					}

				}
			}
		}
		return matrizCores;
	}
	
	public String [][] getMatrizOponente(Jogador oponente)
	{
		Arma [][] matrizOponente = oponente.getMatrizArmas();
		boolean transicaoTurno = controlador.getTransicao();
		String[][] matrizCores = new String[15][15];
		Arma armaAtual = null;
		for (int i = 0; i < 15; i++) 
		{
			for (int j = 0; j < 15; j++) 
			{
				if (transicaoTurno) 
				{
					matrizCores[i][j] = "transicao";
				} 
				else 
				{
					armaAtual = matrizOponente[i][j];
					if(oponente.verificarTiroAgua(i, j) == true)
					{
						
						matrizCores[i][j] = "tiroAgua";
					}
					if(armaAtual != null)
					{
						if (armaAtual.foiDestruida())
							matrizCores[i][j] = "destruida";
						else if(armaAtual.verificarCasasDestruidas(i, j) == true)
							matrizCores[i][j] = "casaDestruida";
					}
					
					
				}
			}
		}

		return matrizCores;
		
		
	}
	


	 
	
	  public void verificarCasaSelecionada(int i,int j) 
	  {
		  if(!controlador.getTransicao())
			  ctrlRegrasAtaques.verificarCasaSelecionada(i,j);
	  }
	 
	  
	  public String getNomeJogadorAtual()
	  {
		  return controlador.getJogadorAtual().getNome();
	  }
	  
	  public String getNomeOponente()
	  {
		  return controlador.getOponente().getNome();
	  }

	  public void mudarVez()
	  {
		 boolean jogoEncerrado = controlador.mudarVezFaseAtaques();
		 if(!jogoEncerrado)
		 {
			  if(controlador.getTransicao())
				  ctrlRegrasAtaques.travarTurno();
			  else
			  ctrlRegrasAtaques.novoTurno(controlador.getOponente());
		  }
	  }


		public void registrar(Observer observer)
		{
			ctrlRegrasAtaques.addObserver(observer);
		}

		public String definirMensagem(String mensagem) {
			if(controlador.getTransicao())
				return "Vez de " +controlador.getJogadorAtual().getNome();
			else
				return mensagem;
			
		}

		public void encerrarJogo() {
			controlador.encerrarJogo();
			
		}

}
