package regras;

public class Arma 
{
	private String tipo;
	private int[] coordCentral;
	private String direcao;
	private int numCasas;
	private boolean selecionada;
	private boolean inserida;
	
	
	public Arma(String tipo,int[] coordCentral)
	{
		selecionada = false;
		inserida = false;
		this.tipo = tipo;
		direcao = "direita";
		this.coordCentral = coordCentral;
		if(tipo=="h")
		{
			direcao = "cima";
			numCasas= 3;
			coordCentral[1] +=1;
		}
		else if(tipo == "s")
			numCasas= 1;
		else if(tipo == "d")
			numCasas= 2;
		else if(tipo == "cr")
			numCasas= 4;
		else if(tipo == "co")
			numCasas= 5;
	}
	
	public void setCoordenadas(int i,int j)
	{
		
		coordCentral[0]=i;
		coordCentral[1]=j;

	}
	
	public boolean estaSelecionada()
	{
		return selecionada;
	}
	
	public boolean foiInserida()
	{
		return inserida;
	}
	
	public void tornarInserida()
	{
		inserida = true;
	}
	
	public void alterarStatusArma(boolean status)
	{
		selecionada = status;
	}
	
	public String getTipo()
	{
		return tipo;
	}
	
	public int[] getCoordCentral()
	{
		return coordCentral;
	}
	
	public String getDirecao()
	{
		return direcao;
	}
	
	public void alterarDirecaoNoventaGraus(Boolean sentido)
	{
		if(sentido == true)
		{
			if(direcao == "cima")
				direcao = "direita";
			else if(direcao == "direita")
				direcao = "baixo";
			else if(direcao == "baixo")
				direcao = "esquerda";
			else if(direcao == "esquerda")
				direcao = "cima";
		}
		else
		{
			if(direcao == "cima")
				direcao = "esquerda";
			else if(direcao == "esquerda")
				direcao = "baixo";
			else if(direcao == "baixo")
				direcao = "direita";
			else if(direcao == "direita")
				direcao = "cima";
		}
		
	}
	
	public int[][] getCasas()
	{
		int[][] matrizCasas = new int[numCasas][2];
		int cont;
		if(tipo == "h")
		{
			if(direcao == "cima")
			{
				matrizCasas[0][0]=coordCentral[0];
				matrizCasas[0][1]=coordCentral[1]-1;
				matrizCasas[1][0]=coordCentral[0]-1;
				matrizCasas[1][1]=coordCentral[1];
				matrizCasas[2][0]=coordCentral[0];
				matrizCasas[2][1]=coordCentral[1]+1;
			}
			else if(direcao == "direita")
			{
				matrizCasas[0][0]=coordCentral[0]-1;
				matrizCasas[0][1]=coordCentral[1];
				matrizCasas[1][0]=coordCentral[0];
				matrizCasas[1][1]=coordCentral[1]+1;
				matrizCasas[2][0]=coordCentral[0]+1;
				matrizCasas[2][1]=coordCentral[1];
			}
			else if(direcao == "baixo")
			{
				matrizCasas[0][0]=coordCentral[0];
				matrizCasas[0][1]=coordCentral[1]-1;
				matrizCasas[1][0]=coordCentral[0];
				matrizCasas[1][1]=coordCentral[1]+1;
				matrizCasas[2][0]=coordCentral[0]+1;
				matrizCasas[2][1]=coordCentral[1];
			}
			else if(direcao == "esquerda")
			{
				matrizCasas[0][0]=coordCentral[0]-1;
				matrizCasas[0][1]=coordCentral[1];
				matrizCasas[1][0]=coordCentral[0];
				matrizCasas[1][1]=coordCentral[1]-1;
				matrizCasas[2][0]=coordCentral[0]+1;
				matrizCasas[2][1]=coordCentral[1];
			}
			
		}
		else if(tipo=="s")
		{
			matrizCasas[0][0]=coordCentral[0];
			matrizCasas[0][1]=coordCentral[1];
		}
		else
		{
			if(direcao == "cima")
			{
				for(cont = 0;cont < numCasas; cont++)
				{
					matrizCasas[cont][0]=coordCentral[0]-cont;
					matrizCasas[cont][1]=coordCentral[1];
				}
			}
			else if(direcao == "direita")
			{
				for(cont = 0;cont < numCasas; cont++)
				{
					matrizCasas[cont][0]=coordCentral[0];
					matrizCasas[cont][1]=coordCentral[1]+cont;
				}
			}
			else if(direcao == "baixo")
			{
				for(cont = 0;cont < numCasas; cont++)
				{
					matrizCasas[cont][0]=coordCentral[0]+cont;
					matrizCasas[cont][1]=coordCentral[1];
				}
			}
			else if(direcao == "esquerda")
			{
				for(cont = 0;cont < numCasas; cont++)
				{
					matrizCasas[cont][0]=coordCentral[0];
					matrizCasas[cont][1]=coordCentral[1]-cont;
				}
			}
		}
		return matrizCasas;
	}
	
	
	
	
	public boolean testarLimitesTabuleiro(int [] novaCoordCentral)
	{
		int coordAntigaX = coordCentral[0];
		int coordAntigaY = coordCentral[1];
		setCoordenadas(novaCoordCentral[0],novaCoordCentral[1]);
		int [][] casasArma = getCasas();
		for (int linha = 0;linha<casasArma.length;linha++)
		{
			if(casasArma[linha][0]<0 || casasArma[linha][0]>14 || casasArma[linha][1]<0 || casasArma[linha][1]>14 )
			{
				setCoordenadas(coordAntigaX,coordAntigaY);
				return false;
			}
		}
		setCoordenadas(coordAntigaX,coordAntigaY);
		return true;
	}
	
	
	
	public boolean testarCompartilhamentoVertices(Arma arma,int [] novaCoordCentral)
	{
		int[][] casasArmaTabuleiro = arma.getCasas();
		int coordAntigaX = coordCentral[0];
		int coordAntigaY = coordCentral[1];
		debug(Integer.toString(coordAntigaX));
		debug(Integer.toString(coordAntigaY));
		setCoordenadas(novaCoordCentral[0],novaCoordCentral[1]);
		int[][] casasArmaSelecionada = getCasas();
		int coordXArmaTabuleiro,coordYArmaTabuleiro;
		int coordXArmaSelecionada,coordYArmaSelecionada;
		for(int casaArmaTabuleiro=0;casaArmaTabuleiro<casasArmaTabuleiro.length;casaArmaTabuleiro++)
		{
			coordXArmaTabuleiro = casasArmaTabuleiro[casaArmaTabuleiro][0];
			coordYArmaTabuleiro = casasArmaTabuleiro[casaArmaTabuleiro][1];
			for(int casaArmaSelecionada=0;casaArmaSelecionada<casasArmaSelecionada.length;casaArmaSelecionada++) 
			{
				coordXArmaSelecionada = casasArmaSelecionada[casaArmaSelecionada][0];
				coordYArmaSelecionada = casasArmaSelecionada[casaArmaSelecionada][1];
				if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada,coordYArmaSelecionada))
				{
					setCoordenadas(coordAntigaX,coordAntigaY);
					return false;
				}
					
				if(coordYArmaSelecionada!=0)
				{
					if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada,coordYArmaSelecionada-1))
					{
						setCoordenadas(coordAntigaX,coordAntigaY);
						return false;
					}
		
					if(coordXArmaSelecionada != 0)
					{
						if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada-1,coordYArmaSelecionada-1))
						{
							setCoordenadas(coordAntigaX,coordAntigaY);
							return false;
						}
					}
					if(coordXArmaSelecionada != 14)
					{
						if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada+1,coordYArmaSelecionada-1))
						{
							setCoordenadas(coordAntigaX,coordAntigaY);
							return false;
						}
					}
				}
				
				if(coordYArmaSelecionada!=14)
				{
					if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada,coordYArmaSelecionada+1))
					{
						setCoordenadas(coordAntigaX,coordAntigaY);
						return false;
					}
					if(coordXArmaSelecionada != 0)
					{
						if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada-1,coordYArmaSelecionada+1))
						{
							setCoordenadas(coordAntigaX,coordAntigaY);
							return false;
						}
					}
					if(coordXArmaSelecionada != 14)
					{
						if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada+1,coordYArmaSelecionada+1))
						{
							setCoordenadas(coordAntigaX,coordAntigaY);
							return false;
						}
				
					}
				}
				if(coordXArmaSelecionada!=0)
				{
					if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada-1,coordYArmaSelecionada))
					{
						setCoordenadas(coordAntigaX,coordAntigaY);
						return false;
					}
				}
				if(coordXArmaSelecionada!=14)
				{
					if(compararCoordenadas(coordXArmaTabuleiro,coordYArmaTabuleiro,coordXArmaSelecionada+1,coordYArmaSelecionada))
					{
						setCoordenadas(coordAntigaX,coordAntigaY);
						return false;
					}
				}
			}
		}
		setCoordenadas(coordAntigaX,coordAntigaY);
		return true;
	}
	
	
	private boolean compararCoordenadas(int coordXVertice1,int coordYVertice1,int coordXVertice2,int coordYVertice2)
	{
		return coordXVertice1 == coordXVertice2 && coordYVertice1 == coordYVertice2;
	}
	
	//DEBUG-Tirar dps
	
	
	private void debug(String msg)
	{
		System.out.println(msg);
	}
	
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
}


