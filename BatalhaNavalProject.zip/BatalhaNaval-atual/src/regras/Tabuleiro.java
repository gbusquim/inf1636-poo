package regras;

import java.util.ArrayList;
import java.util.List;

class Tabuleiro implements Observable {
	Arma[][] matrizTabuleiro ;
	Arma[][] matrizPecasAEscolher ; 
	private Arma listaArmas[];
	private int numArmas;
	private Arma armaSelecionada=null;
	private List<Observer> listaObservers = new ArrayList<Observer>();
	private boolean tabuleiroCompleto;
	private Arma[] hidroavioes;
	private Arma[] submarinos;
	private Arma[] destroyers;
	private Arma[] cruzadores;
	private Arma couracado;
	
	
	
	public Tabuleiro() 
	{
		
		matrizPecasAEscolher =  new Arma[14][19]; 
		matrizTabuleiro = new Arma[15][15];
		tabuleiroCompleto  = false;
		hidroavioes = new Arma[5];
		submarinos = new Arma[4];
		destroyers = new Arma[3];
		cruzadores = new Arma[2];
		numArmas = 0;
		listaArmas = new Arma[15];
		int cont;
		
		for(cont=0;cont< 13;cont++)
		{
			matrizPecasAEscolher[cont] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		
		for(cont = 0;cont< 5; cont ++)
		{
			int[] coordCentral = {1,cont*4};
			hidroavioes[cont]=new Arma("h",coordCentral);
		}
		
		for(cont = 0;cont< 4; cont ++)
		{
			int[] coordCentral = {4,cont*2};
			submarinos[cont]=new Arma("s",coordCentral);
		}
		
		for(cont = 0;cont< 3; cont ++)
		{
			int[] coordCentral = {7,cont*3};
			destroyers[cont]=new Arma("d",coordCentral);
		}
		
		for(cont = 0;cont< 2; cont ++)
		{
			int[] coordCentral = {10,cont*5};
			cruzadores[cont]=new Arma("cr",coordCentral);
		}
		
		int [] coordCentral = {13,0};
		couracado = new Arma("co",coordCentral);
		
		inicializarMatrizes();
		
	}
		
		
	
	public Arma[][] getMatrizTabuleiro() {
		return matrizTabuleiro;
	}
	
	public Arma[][] getMatrizPecasAEscolher() {
		return matrizPecasAEscolher;
	}
	
	
	public void limparTabuleiro()
	{
		numArmas = 0;
		int cont;
		inicializarMatrizes();
		for(cont = 0;cont< 5; cont ++)
		{
			int[] coordCentral = {1,cont*4+1};
			hidroavioes[cont].alterarCoordenadas(coordCentral);
			hidroavioes[cont].alterarStatusInserida(false);
			hidroavioes[cont].alterarDirecao("cima");
		}
		
		for(cont = 0;cont< 4; cont ++)
		{
			int[] coordCentral = {4,cont*2};
			submarinos[cont].alterarCoordenadas(coordCentral);
			submarinos[cont].alterarStatusInserida(false);
			submarinos[cont].alterarDirecao("direita");
		}
		
		for(cont = 0;cont< 3; cont ++)
		{
			int[] coordCentral = {7,cont*3};
			destroyers[cont].alterarCoordenadas(coordCentral);
			destroyers[cont].alterarStatusInserida(false);
			destroyers[cont].alterarDirecao("direita");
		}
		
		for(cont = 0;cont< 2; cont ++)
		{
			int[] coordCentral = {10,cont*5};
			cruzadores[cont].alterarCoordenadas(coordCentral);
			cruzadores[cont].alterarStatusInserida(false);
			cruzadores[cont].alterarDirecao("direita");
		}
		
		int [] coordCentral = {13,0};
		couracado.alterarCoordenadas(coordCentral);
		couracado.alterarStatusInserida(false);
		couracado.alterarDirecao("direita");
		
		notificarObservers();
	}
	
	private void inicializarMatrizes()
	{
		int i;
		
		for(i=0;i< 15;i++)
		{
			matrizTabuleiro[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		
		matrizPecasAEscolher[0] = new Arma[]{null,hidroavioes[0],null,null,null,hidroavioes[1],null,null,null,hidroavioes[2],null,null,null,hidroavioes[3],null,null,null,hidroavioes[4],null};
		
		matrizPecasAEscolher[1] = new Arma[]{hidroavioes[0],null,hidroavioes[0],null,hidroavioes[1],null,hidroavioes[1],null,hidroavioes[2],null,hidroavioes[2],null,hidroavioes[3],null,hidroavioes[3],null,hidroavioes[4],null,hidroavioes[4]};
		
		matrizPecasAEscolher[4] = new Arma[]{submarinos[0],null,submarinos[1],null,submarinos[2],null,submarinos[3],null,null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[7] = new Arma[]{destroyers[0],destroyers[0],null,destroyers[1],destroyers[1],null,destroyers[2],destroyers[2],null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[10] = new Arma[]{cruzadores[0],cruzadores[0],cruzadores[0],cruzadores[0],null,cruzadores[1],cruzadores[1],cruzadores[1],cruzadores[1],null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[13] = new Arma[]{couracado,couracado,couracado,couracado,couracado,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		
		
	}
	

	public void deselecionaNavio()
	{
		if(armaSelecionada!=null)
		{
			armaSelecionada.alterarStatusArma(false);
			armaSelecionada = null;
			if(numArmas==3)
				tabuleiroCompleto = true;
			notificarObservers();
		}
	}
	
	public void moverArma(Arma armaSelecionada,int i,int j)
	{
		int [] novaCoordCentral = {i,j};
		boolean possivelInserir = testarMoverPeca(novaCoordCentral);
		int linha;
		
		if(possivelInserir == true)
		{
			
			int [][] casasArma = armaSelecionada.getCasas();
			exibirMatriz(casasArma);
			if(!armaSelecionada.foiInserida())
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
					matrizPecasAEscolher[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
				armaSelecionada.alterarStatusInserida(true);
				listaArmas[numArmas] = armaSelecionada;
				numArmas++;
				
			}
			else
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
					matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
			}
			
			armaSelecionada.alterarCoordenadas(novaCoordCentral);
			casasArma = armaSelecionada.getCasas();
			for(linha = 0;linha<casasArma.length;linha++)
			{
				matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = armaSelecionada;
			}
		}
		
	}


	public void selecionarArma(String pos,int i, int j) 
	{
		Arma armaEscolhida;
		if(pos=="esq")
			armaEscolhida= matrizPecasAEscolher[i][j];
		else
		{
			armaEscolhida = matrizTabuleiro[i][j];
			if(armaEscolhida == null && armaSelecionada != null)
			{
				moverArma(armaSelecionada,i,j);
				notificarObservers();

			}
		}
		if(armaEscolhida != null)
		{
			if(armaSelecionada!=null)
				armaSelecionada.alterarStatusArma(false);
			armaSelecionada = armaEscolhida;
			armaEscolhida.alterarStatusArma(true);
			tabuleiroCompleto = false;
			notificarObservers();
		}

	}
	
	
	public void rotacionarArma() 
	{
		
		if(armaSelecionada!=null && armaSelecionada.foiInserida())
		{
			
			int linha;
			int [][] casasArmaAnterior = armaSelecionada.getCasas();
			armaSelecionada.alterarDirecaoNoventaGraus(true);
			boolean possivelInserir = testarRotacionarPeca(); 
			if(possivelInserir)
			{
				for(linha = 0;linha<casasArmaAnterior.length;linha++)
				{
					matrizTabuleiro[casasArmaAnterior[linha][0]][casasArmaAnterior[linha][1]] = null;
				}
				int [][] casasArmaAtual = armaSelecionada.getCasas();
				for(linha = 0;linha<casasArmaAtual.length;linha++)
				{
					matrizTabuleiro[casasArmaAtual[linha][0]][casasArmaAtual[linha][1]] = armaSelecionada;
				}
				notificarObservers();
			}
			else
			{
				armaSelecionada.alterarDirecaoNoventaGraus(false);
			}
			
		}
	}
	
	public boolean getStatusTabuleiro()
	{
		return tabuleiroCompleto;
	}

	
	private boolean testarMoverPeca(int [] novaCoordCentral)
	{
		boolean armaEncaixaTabuleiro = armaSelecionada.testarLimitesTabuleiro(novaCoordCentral);
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
		else
		{
			armaNaoCompartilhaVerticeVizinho = testarConflitoVizinhos(novaCoordCentral);
			if(!armaNaoCompartilhaVerticeVizinho)
				return false;
		}
		return true;
		
	}

	private boolean testarRotacionarPeca()
	{
		int [] coordCentral = armaSelecionada.getCoordCentral();
		boolean armaEncaixaTabuleiro = armaSelecionada.testarLimitesTabuleiro(coordCentral);
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
		else
		{
			armaNaoCompartilhaVerticeVizinho = testarConflitoVizinhos(coordCentral);
			if(!armaNaoCompartilhaVerticeVizinho)
				return false;
		}
		return true;
		
	}
	
	private boolean testarConflitoVizinhos(int[] novaCoordCentral)
	{
		boolean armaNaoCompartilhaVerticeVizinho;
		for (int cont = 0;cont<numArmas;cont++)
		{
			Arma armaTabuleiro = listaArmas[cont];
			if(armaTabuleiro!=armaSelecionada)
			{

				armaNaoCompartilhaVerticeVizinho = armaSelecionada.testarCompartilhamentoVertices(armaTabuleiro,novaCoordCentral);
				if(!armaNaoCompartilhaVerticeVizinho)
					return false;
			}
		}
		return true;
	}
	
	public void addObserver(Observer o)
	{
		listaObservers.add(o);
	}

	public void removeObserver(Observer o)
	{
		listaObservers.remove(o);
	}
	
	private void notificarObservers()
	{
		for(Observer o: listaObservers) 
		{
			o.notify(this);
		}
	}
	
	//DEBUG-TIRAR DPS
	private void debug (String msg)
	{
		System.out.println(msg);
	}
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}

	
}
