package regras;

import controlador.ControladorJogo;

public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada=null;
	RegrasFaseAtaques ctrlRegrasAtaques;
	ControladorJogo controlador;
	
	private FachadaFaseAtaques(ControladorJogo controlador) 
	{		
		ctrlRegrasAtaques=new RegrasFaseAtaques();
		this.controlador = controlador;

	}
	
	public static FachadaFaseAtaques getFachada(ControladorJogo controlador) 
	{
		if(fachada==null)
			fachada=new FachadaFaseAtaques(controlador);
		return fachada;
	}
	
	public String[][] getMatriz(String tipoMatriz)
	{
		//pegar momentoDoJogo -> controlador.getPasso;
		boolean transicaoTurno = controlador.getTransicao();
		//Se momento do jogo for standby->TudoAzul
		String[][] matrizCores=new String [15][15];
		Arma [][] matrizArmas=null;
		Arma armaAtual=null;

		for(int i=0; i<15; i++)
		{
		  for(int j=0; j<15; j++)
		  {
			  if(transicaoTurno)
			  {
				  matrizCores[i][j] = "transicao";
			  }
			  else
			  {
				  if(tipoMatriz == "jogadorAtual")
				  {
					  matrizArmas = controlador.getMatrizJogadorAtual();
					  armaAtual = matrizArmas[i][j]; 
					  if(armaAtual == null)
						  matrizCores[i][j] = "";
					  else
					  {
						  if(armaAtual.foiDestruida())
							  matrizCores[i][j] = "destruida";
						  else
						  {
							  matrizCores[i][j] = armaAtual.getTipo();
							  for(int i;i<armaAtual.)
						  }
					  }
				  }
			  }
		  }
		}
		return matrizCores;
	}
			  /*Se momento do jogo for standby->TudoAzul//
			  matrizCores[i][j] = "a";
			  else
			  {
			  if(tipoMatriz == playerAtual)
			  pegar player atual(controlador.playerAtual?)
			  pegar a matriz dele
			  if(matrizArmas for inativa ->preto)
			  pegar partes atingidas e pintar de amarelo
			  matrizCores[i][j] = matrizArmas[i][j].getTipo();
			  else if(tipoMatriz == oponente)
			  {
			  pegar matriz do oponente
			  pegar lista de coordenadas na agua
			  se i e j estao na lista -> matrizCores[i][j] = "agua";
			  else
			  {
			  
			  se for null -> matrizCores[i][j] = "";
			  senao
			pegar lista de coordenadas da arma q ja foram atingidas ->matrizCores[i][j].getCasasAtingidas
			se matrizCores[i][j].getStatusArma for inativo -> matrizCores[i][j] = "armaDestruida -> preto
			  senao
			  ver se e i e j tao na lista de coords ja atingidas-> se tiver matrizCores[i][j] = "pecaAtingida";->amarelo
			
			  
			  }*/
	/*		  }
			  
			  }

				  
		  
		
		return matrizCores;
		

	
	public void trocarJogador() 
	{
		
		//controlador.mudarStatusJogo - coloca jogo em standBy
		//pegar matriz do novoPlayerAtual
		//pegar matriz do novo oponente
		//ctrlRegrasAtaque.setMatriz("oponente");

		
	}
	
	public void verificarCasaSelecionada(int i,int j)
	{
		
		/*boolean jogadaValida = ctrlRegrasAtaque.verificarCasaSelecionada(i,j);
		if(jogadaValida == true)
		{
			controlador.aumentarNumeroJogadas();->tem q notificar o panel pra habilitar o botao depois de 3 jogadas
			
		*/
		
	}
	
//	public Arma[][] getArmas( )
//	{
//		//return controlador.getArmas();
//	}
	

