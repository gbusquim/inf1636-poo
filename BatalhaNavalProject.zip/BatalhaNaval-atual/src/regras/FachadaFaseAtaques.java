package regras;

public class FachadaFaseAtaques {

}
