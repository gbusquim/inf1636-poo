package regras;


public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada=null;
	
	private FachadaFaseAtaques() 
	{
		//criar Controlador,Player,RegrasFaseAtaque

	}
	
	public static FachadaFaseAtaques getFachada() 
	{
		if(fachada==null)
			fachada=new FachadaFaseAtaques();
		return fachada;
	}
	
	public String[][] getMatriz(String tipoMatriz)
	{
		//pegar momentoDoJogo -> controlador.getPasso;
		//Se momento do jogo for standby->TudoAzul
		String[][] matrizTipos=null;
		Arma [][] matrizArmas=null;
		if(tipoMatriz == "tabuleiro")
		{
			matrizTipos = new String[15][15];
			matrizArmas = ctrlRegrasPosicionamento.getMatrizTabuleiro();
		}
		else if(tipoMatriz == "pecasAEscolher")
		{
			matrizTipos = new String[14][19];
			matrizArmas = ctrlRegrasPosicionamento.getMatrizPecasAEscolher();
		}

		for(int i=0; i<15; i++)
		{
		  for(int j=0; j<15; j++)
		  {
			  //Se momento do jogo for standby->TudoAzul//
			  //matrizTipos[i][j] = "a";
			  //else
			  //{
			  //if(tipoMatriz == playerAtual)
			  //pegar player atual(controlador.playerAtual?)
			  //pegar a matriz dele
			  //mostrar do lado esquerdo -> uma cor so
			  //matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  //else if(tipoMatriz == oponente)
			  //{
			  //pegar matriz do oponente
			  //pegar lista de coordenadas na agua
			  //se i e j estao na lista -> matrizTipos[i][j] = "a";
			  //else
			  //{
			  //se for null -> matrizTipos[i][j] = "";
			  //senao
			  //pegar lista de coordenadas da arma q ja foram atingidas
			  //ver se e i e j tao la-> se tiver matrizTipos[i][j] = "amarelo";
			  //se for statusArma for inativo -> matrizTipos[i][j] = "verde";
			  //
			  //}
			  //}
			  
			  //}
			  if(matrizArmas[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizArmas[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
		
	}
	
	public void avancarTurno() 
	{
		
		//controlador.mudarStatusJogo
		
	}
	
}
