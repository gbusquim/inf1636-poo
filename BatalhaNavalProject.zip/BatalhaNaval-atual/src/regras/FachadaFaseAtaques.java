package regras;

import controlador.ControladorJogo;

public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada=null;
	RegrasFaseAtaques ctrlRegrasAtaques;
	ControladorJogo controlador;
	
	private FachadaFaseAtaques(ControladorJogo controlador) 
	{
		//criar Controlador,Player,RegrasFaseAtaque
		//seria bom passar tb o vetor de armas alem da matriz
		
		ctrlRegrasAtaques=new RegrasFaseAtaques();
		this.controlador = controlador;

	}
	
	public static FachadaFaseAtaques getFachada(ControladorJogo controlador) 
	{
		if(fachada==null)
			fachada=new FachadaFaseAtaques(controlador);
		return fachada;
	}
	
	/*public String[][] getMatriz(String tipoMatriz)
	{
		//pegar momentoDoJogo -> controlador.getPasso;
		//Se momento do jogo for standby->TudoAzul
		String[][] matrizTipos=null;
		Arma [][] matrizArmas=null;

		for(int i=0; i<15; i++)
		{
		  for(int j=0; j<15; j++)
		  {*/
			  /*Se momento do jogo for standby->TudoAzul//
			  matrizTipos[i][j] = "a";
			  else
			  {
			  if(tipoMatriz == playerAtual)
			  pegar player atual(controlador.playerAtual?)
			  pegar a matriz dele
			  if(matrizArmas for inativa ->preto)
			  pegar partes atingidas e pintar de amarelo
			  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  else if(tipoMatriz == oponente)
			  {
			  pegar matriz do oponente
			  pegar lista de coordenadas na agua
			  se i e j estao na lista -> matrizTipos[i][j] = "agua";
			  else
			  {
			  
			  se for null -> matrizTipos[i][j] = "";
			  senao
			pegar lista de coordenadas da arma q ja foram atingidas ->matrizTipos[i][j].getCasasAtingidas
			se matrizTipos[i][j].getStatusArma for inativo -> matrizTipos[i][j] = "armaDestruida -> preto
			  senao
			  ver se e i e j tao na lista de coords ja atingidas-> se tiver matrizTipos[i][j] = "pecaAtingida";->amarelo
			
			  
			  }*/
	/*		  }
			  
			  }

				  
		  
		
		return matrizTipos;
		
	}*/
	public String[][] getMatriz(Arma[][] matrizArmas)
	{
		String[][] matrizTipos= new String [matrizArmas.length][matrizArmas[0].length];
//		Arma [][] matrizArmas=null;
//		if(tipoMatriz == "tabuleiro")
//		{
//			matrizTipos = new String[15][15];
//			matrizArmas = ctrlRegrasPosicionamento.getMatrizTabuleiro();
//		}
//		else if(tipoMatriz == "pecasAEscolher")
//		{
//			matrizTipos = new String[14][19];
//			matrizArmas = ctrlRegrasPosicionamento.getMatrizPecasAEscolher();
//		}

		for(int i=0; i<matrizArmas.length; i++)
		{
		  for(int j=0; j<matrizArmas[0].length; j++)
		  {
			  if(matrizArmas[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizArmas[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
	}
	
	public void trocarJogador() 
	{
		
		//controlador.mudarStatusJogo - coloca jogo em standBy
		//pegar matriz do novoPlayerAtual
		//pegar matriz do novo oponente
		//ctrlRegrasAtaque.setMatriz("oponente");

		
	}
	
	public void verificarCasaSelecionada(int i,int j)
	{
		
		/*boolean jogadaValida = ctrlRegrasAtaque.verificarCasaSelecionada(i,j);
		if(jogadaValida == true)
		{
			controlador.aumentarNumeroJogadas();->tem q notificar o panel pra habilitar o botao depois de 3 jogadas
			
		*/
		
	}
	
	public Arma[][] getArmas( )
	{
		return controlador.getArmas();
	}
	
}
