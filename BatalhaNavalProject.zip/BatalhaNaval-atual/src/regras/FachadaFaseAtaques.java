package regras;


public class FachadaFaseAtaques {
	private static FachadaFaseAtaques fachada=null;
	
	private FachadaFaseAtaques() 
	{


	}
	
	public static FachadaFaseAtaques getFachada() 
	{
	if(fachada==null)
		fachada=new FachadaFaseAtaques();
	return fachada;
	}
	
	
}
