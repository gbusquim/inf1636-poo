package regras;

import java.util.ArrayList;
import java.util.List;

public class RegrasFaseAtaques {
	Arma[][] matrizJogadorAtual;
	Arma[][] matrizOponente; 
	private List<Observer> listaObservers = new ArrayList<Observer>();
	
	
	
	public RegrasFaseAtaques()
	{
		matrizJogadorAtual =  new Arma[15][15]; 
		matrizOponente = new Arma[15][15];
	}
	
	
	public void setMatriz(Arma[][] matrizArmas,String tipoMatriz)
	{
		  for (int i = 0; i < 15; i++) 
		  {  
		       for (int j = 0; j < 15; j++)     
		       {
		    	   if(tipoMatriz == "JogadorAtual")
		    		   matrizJogadorAtual[i][j] = matrizArmas[i][j]; 
		    	   else if(tipoMatriz == "Oponente")
		    		   matrizOponente[i][j] = matrizArmas[i][j]; 
		       }  
	
		  }
	}
	
	
	
}
