package regras;

public class Jogador 
{
	private String nome;
	private Arma[][] matrizArmas;
	




	public Jogador(String nome)
	{
		this.nome = nome;
	}

}