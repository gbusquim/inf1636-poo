package regras;

public class Jogador 
{
	private String nome;
	private Arma[][] matrizArmas;

	public Jogador(String nome)
	{
		this.nome = nome;
		this.matrizArmas = new Arma[15][15];
		
	}
	public void setArmas(Arma armas[][])
	{
		for (int i = 0; i < 15; i++)
			for (int j = 0; j < 15; j++)
				matrizArmas[i][j] = armas[i][j];
	}
	public Arma[][] getArmas( )
	{
		return matrizArmas;
	}
	public String getNome()
	{
		return nome;
	}
}
