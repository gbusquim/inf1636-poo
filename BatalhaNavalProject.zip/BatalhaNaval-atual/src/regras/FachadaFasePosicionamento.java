package regras;

import controlador.ControladorJogo;

public class FachadaFasePosicionamento {
	private static FachadaFasePosicionamento fachada=null;
	RegrasFasePosicionamento ctrlRegrasPosicionamento;
	ControladorJogo controlador;
	
	
	private FachadaFasePosicionamento(ControladorJogo controlador) 
	{
		ctrlRegrasPosicionamento=new RegrasFasePosicionamento();
		this.controlador = controlador;
	}
	
	public static FachadaFasePosicionamento getFachada(ControladorJogo controlador) 
	{
	if(fachada==null)
		fachada=new FachadaFasePosicionamento(controlador);
	return fachada;
	}
	
	public String[][] getMatriz(Arma[][] matrizArmas)
	{
		String[][] matrizTipos= new String [matrizArmas.length][matrizArmas[0].length];
//		Arma [][] matrizArmas=null;
//		if(tipoMatriz == "tabuleiro")
//		{
//			matrizTipos = new String[15][15];
//			matrizArmas = ctrlRegrasPosicionamento.getMatrizTabuleiro();
//		}
//		else if(tipoMatriz == "pecasAEscolher")
//		{
//			matrizTipos = new String[14][19];
//			matrizArmas = ctrlRegrasPosicionamento.getMatrizPecasAEscolher();
//		}

		for(int i=0; i<matrizArmas.length; i++)
		{
		  for(int j=0; j<matrizArmas[0].length; j++)
		  {
			  if(matrizArmas[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizArmas[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
		
	}
	
	
	public void verificaNavioSelecionado(String pos,int i,int j)
	{
		ctrlRegrasPosicionamento.selecionarArma(pos,i,j);
	
	}
	
	public String getVez()
	{
		//controlador.getVez();
		return "JJ1";
	
	}

	public void deselecionaNavio()
	{
		ctrlRegrasPosicionamento.deselecionaNavio();
	}
	
	public void registrar(Observer observer)
	{
		
		ctrlRegrasPosicionamento.addObserver(observer);
	}

	public void rotacionarArma()
	{
		ctrlRegrasPosicionamento.rotacionarArma();
	}

	public boolean getStatusTabuleiro() 
	{
		return ctrlRegrasPosicionamento.getStatusTabuleiro();
	}
	
	public void avancarTurno() 
	{
		//controlador.mudarVez();
		ctrlRegrasPosicionamento.limparTabuleiro();
	}
	
	private void exibirMatriz(String[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}

}
