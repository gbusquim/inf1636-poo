package regras;

public class Fachada {
	private static Fachada fachada=null;
	CtrlRegras ctrl;
	Arma arma;
	
	private Fachada() 
	{
		ctrl=new CtrlRegras();
	}
	
	public static Fachada getFachada() 
	{
	if(fachada==null)
		fachada=new Fachada();
	return fachada;
	}
	
	public String[][] getMatriz(String tipoMatriz)
	{
		String[][] matrizTipos;
		Arma [][] matrizArmas;
		if(tipoMatriz == "tabuleiro")
		{
			matrizTipos = new String[15][15];
			matrizArmas = ctrl.getMatrizTabuleiro();
		}
		else //tratar erro se parametro vier diferente do esperado
		{
			matrizTipos = new String[14][19];
			matrizArmas = ctrl.getMatrizPecasAEscolher();
		}

		for(int i=0; i<matrizArmas.length; i++)
		{
		  for(int j=0; j<matrizArmas[0].length; j++)
		  {
			  if(matrizArmas[i][j] == null)
				  matrizTipos[i][j] = "";
			  else
			  {
				  if(matrizArmas[i][j].estaSelecionada())
					  matrizTipos[i][j] = "S";
				  else
					  matrizTipos[i][j] = matrizArmas[i][j].getTipo();
			  }
				  
		  }
		}
		return matrizTipos;
		
	}
	
	public void verificaNavioSelecionado(String pos,int i,int j)
	{
		ctrl.selecionarArma(pos,i,j);
	
	}

	public void deselecionaNavio()
	{
		ctrl.deselecionaNavio();
	}
	
	public void registrar(Observer observer)
	{
		ctrl.addObserver(observer);
	}

	public void rotacionarArma()
	{
		ctrl.rotacionarArma();
	}

	public boolean getStatusTabuleiro() 
	{
		return ctrl.getStatusTabuleiro();
	}

}
