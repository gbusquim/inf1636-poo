package regras;

public class CtrlRegras {
	Arma[][] matrizTabuleiro = new Arma[15][15];
	Arma[][] matrizPecasAEscolher = new Arma[14][19]; 
	private Arma listaArmas[] = new Arma[15];
	private int numArmas = 0;
	private Arma armaSelecionada=null;
	
	public CtrlRegras() 
	{
		int i;
		Arma[] hidroavioes = new Arma[5];
		Arma[] submarinos = new Arma[4];
		Arma[] destroyers = new Arma[3];
		Arma[] cruzadores = new Arma[2];
		Arma couracado;
		
		for(i=0;i< 15;i++)
		{
			matrizTabuleiro[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		for(i=0;i< 13;i++)
		{
			matrizPecasAEscolher[i] = new Arma[]{null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
		}
		
		for(int cont = 0;cont< 5; cont ++)
		{
			int[] coordCentral = {1,cont*4};
			hidroavioes[cont]=new Arma("h",coordCentral);
		}
		
		for(int cont = 0;cont< 4; cont ++)
		{
			int[] coordCentral = {4,cont*2};
			submarinos[cont]=new Arma("s",coordCentral);
		}
		
		for(int cont = 0;cont< 3; cont ++)
		{
			int[] coordCentral = {7,cont*3};
			destroyers[cont]=new Arma("d",coordCentral);
		}
		
		for(int cont = 0;cont< 2; cont ++)
		{
			int[] coordCentral = {10,cont*5};
			cruzadores[cont]=new Arma("cr",coordCentral);
		}
		
		int [] coordCentral = {13,0};
		couracado = new Arma("co",coordCentral);
		
		matrizPecasAEscolher[0] = new Arma[]{null,hidroavioes[0],null,null,null,hidroavioes[1],null,null,null,hidroavioes[2],null,null,null,hidroavioes[3],null,null,null,hidroavioes[4],null};
		
		matrizPecasAEscolher[1] = new Arma[]{hidroavioes[0],null,hidroavioes[0],null,hidroavioes[1],null,hidroavioes[1],null,hidroavioes[2],null,hidroavioes[2],null,hidroavioes[3],null,hidroavioes[3],null,hidroavioes[4],null,hidroavioes[4]};
		
		matrizPecasAEscolher[4] = new Arma[]{submarinos[0],null,submarinos[1],null,submarinos[2],null,submarinos[3],null,null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[7] = new Arma[]{destroyers[0],destroyers[0],null,destroyers[1],destroyers[1],null,destroyers[2],destroyers[2],null,null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[10] = new Arma[]{cruzadores[0],cruzadores[0],cruzadores[0],cruzadores[0],null,cruzadores[1],cruzadores[1],cruzadores[1],cruzadores[1],null,null,null,null,null,null,null,null,null,null};
		
		matrizPecasAEscolher[13] = new Arma[]{couracado,couracado,couracado,couracado,couracado,null,null,null,null,null,null,null,null,null,null,null,null,null,null};
	}
		
		
	
	public Arma[][] getMatrizTabuleiro() {
		return matrizTabuleiro;
	}
	
	public Arma[][] getMatrizPecasAEscolher() {
		return matrizPecasAEscolher;
	}
	
	
	

	public void deselecionaNavio()
	{
		if(armaSelecionada!=null)
			armaSelecionada.alterarStatusArma(false);
		armaSelecionada = null;
	}
	
	public void moverArma(Arma armaSelecionada,int i,int j)
	{
		boolean possivelInserir = testarMoverPeca(i,j);
		int linha;
		if(possivelInserir == true)
		{
			
			int [][] casasArma = armaSelecionada.getCasas();
			exibirMatriz(casasArma);
			if(!armaSelecionada.foiInserida())
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
		
					matrizPecasAEscolher[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
				armaSelecionada.tornarInserida();
				listaArmas[numArmas] = armaSelecionada;
				numArmas++;
				
			}
			else
			{
				for(linha = 0;linha<casasArma.length;linha++)
				{
					matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = null;
				}
			}
			
			armaSelecionada.setCoordenadas(i,j);
			casasArma = armaSelecionada.getCasas();
			for(linha = 0;linha<casasArma.length;linha++)
			{
				matrizTabuleiro[casasArma[linha][0]][casasArma[linha][1]] = armaSelecionada;
			}
		}
		
	}


	public void selecionarArma(String pos,int i, int j) 
	{
		Arma armaEscolhida;
		if(pos=="esq")
			armaEscolhida= matrizPecasAEscolher[i][j];
		else
		{
			armaEscolhida = matrizTabuleiro[i][j];
			if(armaEscolhida == null && armaSelecionada != null)
			{
				moverArma(armaSelecionada,i,j);

			}
		}
		if(armaEscolhida != null)
		{
			if(armaSelecionada!=null)
				armaSelecionada.alterarStatusArma(false);
			armaSelecionada = armaEscolhida;
			armaEscolhida.alterarStatusArma(true);
		}
		//exibirMatriz(armaSelecionada.getCasas());
	}
	
	
	public void rotacionarArma() 
	{
		
		if(armaSelecionada!=null && armaSelecionada.foiInserida())
		{
			
			int linha;
			int [][] casasArmaAnterior = armaSelecionada.getCasas();
			armaSelecionada.alterarDirecaoNoventaGraus(true);
			boolean possivelInserir = testarRotacionarPeca(); 
			if(possivelInserir)
			{
				for(linha = 0;linha<casasArmaAnterior.length;linha++)
				{
					matrizTabuleiro[casasArmaAnterior[linha][0]][casasArmaAnterior[linha][1]] = null;
				}
				int [][] casasArmaAtual = armaSelecionada.getCasas();
				for(linha = 0;linha<casasArmaAtual.length;linha++)
				{
					matrizTabuleiro[casasArmaAtual[linha][0]][casasArmaAtual[linha][1]] = armaSelecionada;
				}
			}
			else
			{
				armaSelecionada.alterarDirecaoNoventaGraus(false);
			}
			
		}
	}
	
	

	
	private boolean testarMoverPeca(int i,int j)
	{
		int [] novaCoordCentral = {i,j};
		boolean armaEncaixaTabuleiro = armaSelecionada.testarLimitesTabuleiro(novaCoordCentral);
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
		else
		{
			armaNaoCompartilhaVerticeVizinho = testarConflitoVizinhos(novaCoordCentral);
			if(!armaNaoCompartilhaVerticeVizinho)
				return false;
		}
		return true;
		
	}

	private boolean testarRotacionarPeca()
	{
		int [] coordCentral = armaSelecionada.getCoordCentral();
		boolean armaEncaixaTabuleiro = armaSelecionada.testarLimitesTabuleiro(coordCentral);
		boolean armaNaoCompartilhaVerticeVizinho;
		if(!armaEncaixaTabuleiro)
			return false;
		else
		{
			armaNaoCompartilhaVerticeVizinho = testarConflitoVizinhos(coordCentral);
			if(!armaNaoCompartilhaVerticeVizinho)
				return false;
		}
		return true;
		
	}
	
	private boolean testarConflitoVizinhos(int[] novaCoordCentral)
	{
		boolean armaNaoCompartilhaVerticeVizinho;
		for (int cont = 0;cont<numArmas;cont++)
		{
			Arma armaTabuleiro = listaArmas[cont];
			if(armaTabuleiro!=armaSelecionada)
			{

				armaNaoCompartilhaVerticeVizinho = armaSelecionada.testarCompartilhamentoVertices(armaTabuleiro,novaCoordCentral);
				if(!armaNaoCompartilhaVerticeVizinho)
					return false;
			}
		}
		return true;
	}
	
	
	//DEBUG-TIRAR DPS
	private void debug(String msg)
	{
		System.out.println(msg);
	}
	
	
	private void exibirMatriz(int[][] matriz)
	{
		  for (int l = 0; l < matriz.length; l++) 
		  {  
		       for (int c = 0; c < matriz[0].length; c++)     
		       { 
		           System.out.print(matriz[l][c] + " "); 
		       }  
		       System.out.println(" "); 
	
		  }
	}
	
}
