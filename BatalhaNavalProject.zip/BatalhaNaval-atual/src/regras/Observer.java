package regras;

public interface Observer {
	public void notify(Observable o);
}
