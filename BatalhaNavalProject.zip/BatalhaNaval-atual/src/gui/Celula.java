package gui;

class Celula {
	int x,y;
	
	Celula(int x,int y) {
		this.x=x;
		this.y=y;
	}
}
