package gui;

import regras.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

import controlador.EscolherModoJogo;

public class FRFasePosicionamento extends JFrame {
	final int LARG_DEFAULT=1280;
	final int ALT_DEFAULT=720;
	
	
	
	
	public FRFasePosicionamento(FachadaFasePosicionamento fachada) {
		Toolkit tk=Toolkit.getDefaultToolkit();
		Dimension screenSize=tk.getScreenSize();
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu menuJogo = new JMenu("Jogo");
		menuBar.add(menuJogo);
		
		JMenuItem recarregar = new JMenuItem("Recarregar Jogo Anterior");
		JMenuItem encerrarJogo = new JMenuItem("Encerrar Jogo");
		
		menuJogo.add(recarregar);
		menuJogo.add(encerrarJogo);
		
		recarregar.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	//fachada.avancarTurno();
	        	System.out.println("tfeygeyf");

	        }
	    });
		
		encerrarJogo.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	//fachada.avancarTurno();
	        	setVisible(false);
	        	new EscolherModoJogo();

	        }
	    });
		
		
		PNFasePosicionamento Jpanel = new PNFasePosicionamento(fachada);
		int sl=screenSize.width;
		int sa=screenSize.height;
		int x=sl/2-LARG_DEFAULT/2;
		int y=sa/2-ALT_DEFAULT/2;
		setBounds(x, y-20,LARG_DEFAULT,ALT_DEFAULT);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		getContentPane().add(Jpanel);
		setTitle("Batalha Naval");
		
		
		setResizable(false);
		setDefaultCloseOperation(EXIT_ON_CLOSE);

	}
	
}
