package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JPanel;

import regras.Arma;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;
import regras.Observable;
import regras.Observer;

public class PNFaseAtaques extends JPanel implements MouseListener,Observer {
	
	private int xIniTabuleiroOponente=795,yIniTabuleiroOponente=75,tamanhoLado=30;
	private int xIniTabuleiroJogadorAtual=45,yIniTabuleiroJogadorAtual=75;
	private Celula celulaTabuleiroOponente[][]=new Celula[15][15];
	private Celula celulaTabuleiroJogadorAtual[][]=new Celula[15][15];
	private FachadaFaseAtaques fachada;
	private JButton botaoAlterarJogador = new JButton("Come�ar Jogo");
	Observable observable;
	
	public PNFaseAtaques(FachadaFaseAtaques fachada)
	{
		int xOponente=xIniTabuleiroOponente,yOponente=yIniTabuleiroOponente;
		int xJogadorAtual = xIniTabuleiroJogadorAtual, yJogadorAtual = yIniTabuleiroJogadorAtual;
		this.fachada=fachada;
		//fachada.registrar(this);
		for(int i=0;i<15;i++) {
			xOponente=xIniTabuleiroOponente;
			for(int j=0;j<15;j++) {
				celulaTabuleiroOponente[i][j]=new Celula(xOponente,yOponente);
				xOponente+=tamanhoLado;
			}
			yOponente+=tamanhoLado;
		}
		
		for(int i=0;i<15;i++) {
			xJogadorAtual=xIniTabuleiroJogadorAtual;
			for(int j=0;j<15;j++) {
				celulaTabuleiroJogadorAtual[i][j]=new Celula(xJogadorAtual,yJogadorAtual);
				xJogadorAtual+=tamanhoLado;
			}
			yJogadorAtual+=tamanhoLado;
		}
		
		addMouseListener(this);
		setFocusable(true);
		setLayout(null);
		botaoAlterarJogador.setBounds(530, 600, 220, 30);
		botaoAlterarJogador.setEnabled(true);
		botaoAlterarJogador.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	//fachada.avancarTurno();

	        }
	    });
		add(botaoAlterarJogador);

	}
	
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		Graphics2D g2d=(Graphics2D) g;
		Rectangle2D rtOponente;
		Rectangle2D rtJogadorAtual;
		//boolean tabuleiroCheio = fachada.getStatusTabuleiro();
		//String matrizTabuleiro[][]=fachada.getMatriz("tabuleiro");
		//String matrizPecasAEscoher[][]=fachada.getMatriz("pecasAEscolher");
		String tabuleiroOponente[][] = new String[15][15];
		String tabuleiroJogadorAtual[][] = new String[15][15];;
		int i,j;
		
		for(i=0;i< 15;i++)
		{
			tabuleiroOponente[i] = new String[]{"","","","","c","","","","","","","","","p",""};
			tabuleiroJogadorAtual[i] = new String[]{"","","","","","","","","","a","","","","",""};
		}
		
		g.setFont (new Font ("Arial", 1, 15) );
		
		for(i=0;i<15;i++)
		{
			g.drawString(Integer.toString(i+1),celulaTabuleiroOponente[0][i].x+8,yIniTabuleiroOponente-5);
			g.drawString(Integer.toString(i+1),celulaTabuleiroJogadorAtual[0][i].x+8,yIniTabuleiroJogadorAtual-5);
			g.drawString(String.valueOf((char)('A'+i)),xIniTabuleiroOponente-17,celulaTabuleiroOponente[i][0].y+20);
			g.drawString(String.valueOf((char)('A'+i)),xIniTabuleiroJogadorAtual-17,celulaTabuleiroJogadorAtual[i][0].y+20);
		}
		


		
		g.drawString("Tabuleiro de J1", xIniTabuleiroJogadorAtual, 35);
		g.drawString("Tabuleiro de J2", xIniTabuleiroOponente, 35);
		g.setColor(Color.red);
		g.drawString("Vis�o bloqueada",583, 580);
		for(i=0;i<15;i++) 
		{
			for(j=0;j<15;j++) 
			{
				if(tabuleiroOponente[i][j]=="a") 
				{
	
					g2d.setPaint(new Color(158, 222, 244));

				}
				else if(tabuleiroOponente[i][j]=="") 
				{
	
					g2d.setPaint(Color.white);

				}
				else if(tabuleiroOponente[i][j]=="p") 
				{
	
					g2d.setPaint(Color.yellow);

				}
				else if(tabuleiroOponente[i][j]=="c") 
				{
	
					g2d.setPaint(new Color(49, 244, 6));

				}
				
				rtOponente=new Rectangle2D.Double(celulaTabuleiroOponente[i][j].x,celulaTabuleiroOponente[i][j].y,tamanhoLado,tamanhoLado);
				g2d.fill(rtOponente);
				g2d.setPaint(Color.black);
				g2d.draw(rtOponente);
				
				if(tabuleiroJogadorAtual[i][j]=="a") 
				{
	
					g2d.setPaint(new Color(158, 222, 244));

				}
				else if(tabuleiroJogadorAtual[i][j]=="") 
				{
	
					g2d.setPaint(Color.white);

				}
				else if(tabuleiroJogadorAtual[i][j]=="p") 
				{
	
					g2d.setPaint(Color.yellow);

				}
				else if(tabuleiroJogadorAtual[i][j]=="c") 
				{
	
					g2d.setPaint(new Color(0, 136, 0));

				}
				rtJogadorAtual=new Rectangle2D.Double(celulaTabuleiroJogadorAtual[i][j].x,celulaTabuleiroJogadorAtual[i][j].y,tamanhoLado,tamanhoLado);
				g2d.fill(rtJogadorAtual);
				g2d.setPaint(Color.black);
				g2d.draw(rtJogadorAtual);
			}
		}
	}
	
	public void mouseClicked(MouseEvent e) 
	{
		int x=e.getX(),y=e.getY();
		int botaoMouse = e.getButton();
		x-=xIniTabuleiroOponente;
		y-=yIniTabuleiroOponente;

		if(botaoMouse == MouseEvent.BUTTON1)
		{
			if((x>0 && y>0 && x<15*tamanhoLado && y<15*tamanhoLado)) // um espa�o foi selecionado
			{
				System.out.println(x/tamanhoLado);
				System.out.println(y/tamanhoLado);
				
				
			}
		}
	}
	

	@Override
	public void notify(Observable o) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	

}
