package controlador;

import regras.*;

import gui.FRFaseAtaques;

public class ControladorJogo {
	private Jogador jogador1,jogador2;
	private Jogador jogadorAtual;
	private String faseJogo;
	private ControladorTelas controladorTelas;
	private boolean transicaoTurno;
	
	public ControladorJogo(ControladorTelas controladorTelas,Jogador jogador1,Jogador jogador2,String faseJogo)
	{
		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		this.faseJogo = faseJogo;
		jogadorAtual = jogador1;
		this.controladorTelas = controladorTelas;
		transicaoTurno = false;
	}
	
	public void mudarVez(Arma armas[][])
	{
		if(faseJogo == "posicionamento")
		{
			if (jogadorAtual == jogador1) 
			{
				jogador1.setArmas(armas);
				jogadorAtual = jogador2;
			} 
			else 
			{
				jogador2.setArmas(armas);
				jogadorAtual = jogador1;
				faseJogo = "ataque";
				transicaoTurno = true;
				controladorTelas.FaseDeAtaques();
			}
		} 
		else if (faseJogo == "ataque") 
		{
			
		}
	}
	public String getNomeJogadorAtual( )
	{
		return jogadorAtual.getNome();
	}
	
	public Boolean getTransicao()
	{
		return transicaoTurno;
	}
	
	public Arma[][] getMatrizJogadorAtual()
	{
		return jogadorAtual.getArmas();
	}
	
	
//	public Arma[][] getArmas( )
//	{
//		return 
//	}
}