package controlador;

import regras.*;

import gui.FRFaseAtaques;

public class ControladorJogo {
	private Jogador jogador1,jogador2;
	private Jogador jogadorAtual;
	private String faseJogo;
	
	public ControladorJogo(Jogador jogador1,Jogador jogador2,String faseJogo)
	{
		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		this.faseJogo = faseJogo;
		jogadorAtual = jogador1;
	}
	
	public void mudarVez(Arma armas[][])
	{
		if(faseJogo == "posicionamento")
		{
			if (jogadorAtual == jogador1) {
				jogador1.setArmas(armas);
				jogadorAtual = jogador2;
			} else {
				jogador2.setArmas(armas);
				jogadorAtual = jogador1;
				faseJogo = "ataque";
				(new FRFaseAtaques(FachadaFaseAtaques.getFachada(this))).setVisible(true);
			}
		} else if (faseJogo == "ataque") {
			
		}
	}
	public String getVez( )
	{
		return jogadorAtual.getNome();
	}
	public Arma[][] getArmas( )
	{
		return jogadorAtual.getArmas();
	}
}