package controlador;

import regras.*;

public class ControladorJogo {
	private Jogador jogador1,jogador2;
	private Jogador jogadorAtual;
	private String faseJogo;
	
	public ControladorJogo(Jogador jogador1,Jogador jogador2,String faseJogo)
	{
		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		this.faseJogo = faseJogo;
		jogadorAtual = jogador1;
	}
	

	
//	public void mudarVez()
//	{
//		if(faseJogo == "posicionamento")
//		{
//			if (playerAtual == 1) 
//				playerAtual = 2;
//		}
//				
//	}
	
	
}