package controlador;

import gui.*;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;

public class EscolherModoJogo {
	
	FREscolherModoJogo emjFrame;
	FREscolherNomesJogadores enjFrame;
	FRFasePosicionamento fpFrame;
	FRFaseAtaques fpFrameAt;

	EscolherModoJogo( ) {
		emjFrame = new FREscolherModoJogo(this);
	}
	public void NovoJogo( ) {
		emjFrame.setVisible(false);
		enjFrame = new FREscolherNomesJogadores(this);
	}
	public void IniciarJogo( ) {
		enjFrame.setVisible(false);
		FachadaFasePosicionamento fachada = FachadaFasePosicionamento.getFachada();
		FachadaFaseAtaques fachadaAt = FachadaFaseAtaques.getFachada();
		//fpFrame = new FRFasePosicionamento(fachada);
		fpFrameAt = new FRFaseAtaques(fachadaAt);
		//fpFrame.setVisible(true);
		fpFrameAt.setVisible(true);
	}
	public static void main(String[] args) {
		new EscolherModoJogo();
	}
}