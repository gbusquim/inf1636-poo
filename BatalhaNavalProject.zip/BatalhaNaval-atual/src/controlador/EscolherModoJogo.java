package controlador;

import gui.*;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;
import regras.Jogador;

public class EscolherModoJogo {
	
	FREscolherModoJogo emjFrame;
	FREscolherNomesJogadores enjFrame;
	FRFasePosicionamento fpFrame;
	FRFaseAtaques fpFrameAt;

	public EscolherModoJogo( ) {
		emjFrame = new FREscolherModoJogo(this);
	}
	public void NovoJogo( ) {
		emjFrame.setVisible(false);
		enjFrame = new FREscolherNomesJogadores(this);
	}
	public void IniciarJogo(String nomeJogador1,String nomeJogador2) {
		enjFrame.setVisible(false);
		Jogador jogador1 = new Jogador(nomeJogador1);
		Jogador jogador2 = new Jogador(nomeJogador2);
		ControladorJogo controlador = new ControladorJogo(jogador1,jogador2,"posicionamento");
		FachadaFasePosicionamento fachada = FachadaFasePosicionamento.getFachada(controlador);
		FachadaFaseAtaques fachadaAt = FachadaFaseAtaques.getFachada();
		fpFrame = new FRFasePosicionamento(fachada);
		//fpFrameAt = new FRFaseAtaques(fachadaAt);
		fpFrame.setVisible(true);
		//fpFrameAt.setVisible(true);
	}
	public static void main(String[] args) {
		new EscolherModoJogo();
	}
}