package controlador;

public class ControleTurno {
	private int playerAtual;
	private String faseJogo;
	
	public ControleTurno()
	{
		playerAtual = 1;
		faseJogo = "posicionamento";
	}
	public void mudarVez()
	{
		if(faseJogo == "posicionamento")
		{
			if (playerAtual == 1) 
				playerAtual = 2;
		}
				
	}
	
	
}