package controlador;

import gui.*;
import regras.DAO;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;
import regras.Jogador;

public class ControladorTelas {
	
	FREscolherModoJogo emjFrame;
	FREscolherNomesJogadores enjFrame;
	FRFasePosicionamento fpFrame;
	FRFaseAtaques faFrame;
	ControladorJogo controlador;

	public ControladorTelas( ) {
		
		emjFrame = new FREscolherModoJogo(this);
	}
	public void NovoJogo( ) {
		emjFrame.setVisible(false);
		enjFrame = new FREscolherNomesJogadores(this);
	}
	public void IniciarJogo(String nomeJogador1,String nomeJogador2) {
		enjFrame.setVisible(false);
		Jogador jogador1 = new Jogador(nomeJogador1);
		Jogador jogador2 = new Jogador(nomeJogador2);
		controlador = new ControladorJogo(this,jogador1,jogador2);
		FachadaFasePosicionamento fachada = FachadaFasePosicionamento.getFachada(controlador);
		//fachada.setControlador(controlador);
		fpFrame = new FRFasePosicionamento(fachada,this);
		fpFrame.setVisible(true);
	}
	public void FaseDeAtaques( ) {
		fpFrame.setVisible(false);
		emjFrame.setVisible(false);
		FachadaFaseAtaques fachadaAtaques = FachadaFaseAtaques.getFachada(controlador);
		faFrame = new FRFaseAtaques(fachadaAtaques,this);
		faFrame.setVisible(true);
	}
	
	public static void main(String[] args) {
		new ControladorTelas();
	}
	public void voltarMenuPrincipal()
	{
		faFrame.setVisible(false);
		emjFrame = new FREscolherModoJogo(this);
		
	}
	public void CarregarJogo() 
	{
		DAO arquivo = DAO.getDAO();
		try 
		{
			//emjFrame.setVisible(false);
			controlador = arquivo.recarregar(this);
			FachadaFaseAtaques fachadaAtaques = FachadaFaseAtaques.getFachada(controlador);
			faFrame = new FRFaseAtaques(fachadaAtaques,this);
			faFrame.setVisible(true);
			
		} 
		catch (Exception e) 
		{
			System.out.println(e.getMessage());
		
		}
	}
	public void salvarJogo() {
		DAO.getDAO().salvarJogo(controlador);
		
	}
}