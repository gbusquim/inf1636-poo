package gui;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;

import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import regras.Arma;
import regras.FachadaFaseAtaques;
import regras.FachadaFasePosicionamento;
import regras.Jogador;
import regras.Observable;
import regras.Observer;

public class PNFaseAtaques extends JPanel implements MouseListener,Observer {
	
	private int xIniTabuleiroOponente=795,yIniTabuleiroOponente=75,tamanhoLado=30;
	private int xIniTabuleiroJogadorAtual=45,yIniTabuleiroJogadorAtual=75;
	private Celula celulaTabuleiroOponente[][]=new Celula[15][15];
	private Celula celulaTabuleiroJogadorAtual[][]=new Celula[15][15];
	private FachadaFaseAtaques fachada;
	private JButton botaoAlterarJogador = new JButton("Come�ar Jogo");
	Observable obs;
	Object lob[];
	String tabuleiroOponente[][];
	String tabuleiroJogadorAtual[][];
	String nomeJogadorAtual;
	String nomeOponente;
	String mensagem;
	boolean fimTurno;
	boolean fimJogo;
	private JMenuItem opcaoSalvar;
	
	public PNFaseAtaques(final FachadaFaseAtaques fachada, JMenuItem salvar)
	{
		int xOponente=xIniTabuleiroOponente,yOponente=yIniTabuleiroOponente;
		int xJogadorAtual = xIniTabuleiroJogadorAtual, yJogadorAtual = yIniTabuleiroJogadorAtual;
		this.fachada=fachada;
		//registrar observer
		fachada.registrar(this);
		opcaoSalvar = salvar;
		for(int i=0;i<15;i++) {
			xOponente=xIniTabuleiroOponente;
			for(int j=0;j<15;j++) {
				celulaTabuleiroOponente[i][j]=new Celula(xOponente,yOponente);
				xOponente+=tamanhoLado;
			}
			yOponente+=tamanhoLado;
		}
		
		for(int i=0;i<15;i++) {
			xJogadorAtual=xIniTabuleiroJogadorAtual;
			for(int j=0;j<15;j++) {
				celulaTabuleiroJogadorAtual[i][j]=new Celula(xJogadorAtual,yJogadorAtual);
				xJogadorAtual+=tamanhoLado;
			}
			yJogadorAtual+=tamanhoLado;
		}
		
		addMouseListener(this);
		setFocusable(true);
		setLayout(null);
		botaoAlterarJogador.setBounds(530, 600, 220, 30);
		botaoAlterarJogador.setEnabled(true);
		botaoAlterarJogador.setFocusPainted(false);
		botaoAlterarJogador.addActionListener(new ActionListener() {
	        public void actionPerformed(ActionEvent e) {
	        	fachada.mudarVez();
	        	tabuleiroJogadorAtual = fachada.getMatrizJogadorAtual();

	        }
	    });
		add(botaoAlterarJogador);
		inicializa();

	}
	
	
	private void inicializa()
	{
		lob = null;
		fimTurno = true;

	}
	
	public void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		Graphics2D g2d=(Graphics2D) g;
		Rectangle2D rtOponente;
		Rectangle2D rtJogadorAtual;
		tabuleiroJogadorAtual = fachada.getMatrizJogadorAtual();
		int i,j;
		
		
	
		
		
		g.setFont (new Font ("Arial", 1, 15) );
		
		for(i=0;i<15;i++)
		{
			g.drawString(Integer.toString(i+1),celulaTabuleiroOponente[0][i].x+8,yIniTabuleiroOponente-5);
			g.drawString(Integer.toString(i+1),celulaTabuleiroJogadorAtual[0][i].x+8,yIniTabuleiroJogadorAtual-5);
			g.drawString(String.valueOf((char)('A'+i)),xIniTabuleiroOponente-17,celulaTabuleiroOponente[i][0].y+20);
			g.drawString(String.valueOf((char)('A'+i)),xIniTabuleiroJogadorAtual-17,celulaTabuleiroJogadorAtual[i][0].y+20);
		}
		


		
		g.drawString("Tabuleiro de "+fachada.getNomeJogadorAtual(), xIniTabuleiroJogadorAtual, 35);
		g.drawString("Tabuleiro de "+fachada.getNomeOponente(), xIniTabuleiroOponente, 35);
		g.setColor(Color.black);
		
		g.drawString(fachada.definirMensagem(mensagem),528, 580);
		
		//tabuleiro do oponente
		for(i=0;i<15;i++) 
		{
			for(j=0;j<15;j++) 
			{
				if(lob == null || tabuleiroOponente[i][j]=="transicao" || tabuleiroOponente[i][j]== "tiroAgua" ) 
				{
					g2d.setPaint(new Color(158, 222, 244));
					

				}
				else if(tabuleiroOponente[i][j]=="armaDestruida") 
				{
	
					g2d.setPaint(Color.gray);

				}
				else if(tabuleiroOponente[i][j]=="casaDestruida") 
				{
					
					g2d.setPaint(Color.red);

				}
				else
					g2d.setPaint(Color.white);

				
				rtOponente=new Rectangle2D.Double(celulaTabuleiroOponente[i][j].x,celulaTabuleiroOponente[i][j].y,tamanhoLado,tamanhoLado);
				g2d.fill(rtOponente);
				g2d.setPaint(Color.black);
				g2d.draw(rtOponente);
				
				//tabuleiro do jogador atual
				if(tabuleiroJogadorAtual[i][j]=="transicao" || tabuleiroJogadorAtual[i][j]=="tiroAgua" ) 
				{
					
					g2d.setPaint(new Color(158, 222, 244));
					

				}
				else if(tabuleiroJogadorAtual[i][j]=="armaDestruida") 
				{
	
					g2d.setPaint(Color.gray);

				}
				else if(tabuleiroJogadorAtual[i][j]=="casaDestruida") 
				{
	
					g2d.setPaint(Color.red);

				}
				else if(tabuleiroJogadorAtual[i][j].equals("espacoVazio")) 
					g2d.setPaint(Color.white);
				else if (tabuleiroJogadorAtual[i][j].equals("hidroaviao"))
					g2d.setPaint(new Color(0, 136, 0));
				else if (tabuleiroJogadorAtual[i][j].equals("submarino"))
					g2d.setPaint(Color.green);
				else if (tabuleiroJogadorAtual[i][j].equals("destroyer"))
					g2d.setPaint(Color.yellow);
				else if (tabuleiroJogadorAtual[i][j].equals("cruzador"))
					g2d.setPaint(Color.orange);
				else if (tabuleiroJogadorAtual[i][j].equals("couracado"))
					g2d.setPaint(new Color(132, 85, 0));
				rtJogadorAtual=new Rectangle2D.Double(celulaTabuleiroJogadorAtual[i][j].x,celulaTabuleiroJogadorAtual[i][j].y,tamanhoLado,tamanhoLado);
				g2d.fill(rtJogadorAtual);
				g2d.setPaint(Color.black);
				g2d.draw(rtJogadorAtual);
			}
		}
		
		
		botaoAlterarJogador.setEnabled(fimTurno);
		botaoAlterarJogador.setText(fachada.definirTextoBotao());
		opcaoSalvar.setEnabled(fachada.getTransicao());
	}
	
	public void mouseClicked(MouseEvent e) 
	{
		int x=e.getX(),y=e.getY();
		int botaoMouse = e.getButton();
		x-=xIniTabuleiroOponente;
		y-=yIniTabuleiroOponente;

		if(botaoMouse == MouseEvent.BUTTON1)
		{
			if((x>0 && y>0 && x<15*tamanhoLado && y<15*tamanhoLado)) // uma casa foi selecionada
			{

				fachada.verificarCasaSelecionada(y/tamanhoLado,x/tamanhoLado);
				
				
			}
		}
	}
	

	public void notify(Observable o) 
	{
		obs=o;
		lob=(Object []) obs.get();
		tabuleiroOponente=fachada.getMatrizOponente((Jogador) lob[0]);
		mensagem=(String) lob[1];
		fimTurno = (Boolean) lob[2];
		fimJogo = (Boolean) lob[3];
		
		String mensagemVitoria = "";
		
		if(fimJogo)
		{
			mensagemVitoria = "Vit�ria de " + fachada.getNomeJogadorAtual() + "!";
			
		}
		repaint();
		if(mensagemVitoria != "")
		{
			JOptionPane.showMessageDialog(this,mensagemVitoria);
			fachada.encerrarJogo();
			repaint();
		}
	}



	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	

}
