package regras;

import java.util.ArrayList;
import java.util.List;

public class RegrasFaseAtaques implements Observable {
	Jogador oponente;
	private List<Observer> listaObservers = new ArrayList<Observer>();
	private int numCasasAgua =0;
	private int numeroJogadas = 0;
	private boolean fimTurno;
	
	
	
	public RegrasFaseAtaques(Jogador oponente)
	{
		this.oponente = oponente;
		numeroJogadas = 0;
		fimTurno = false;
	}
	
	
	
	public void verificarCasaSelecionada(int i,int j)
	{
		Arma armaSelecionada = oponente.getMatrizArmas()[i][j];
		boolean jogadaValida = false;
		if(armaSelecionada == null)
		{
			jogadaValida = oponente.adicionarTiroAgua(i,j);
		}
		else
		{
			if(!armaSelecionada.foiDestruida())
			{
				jogadaValida = armaSelecionada.adicionarCasaDestruida(i, j);
			}
		}
		if(jogadaValida)
		{
			notificarObservers();
			aumentarNumeroJogadas();
		}
		
	}
	
	
	
	public void aumentarNumeroJogadas() {
		numeroJogadas++;
		if(numeroJogadas == 3)
		{
			notificarObservers();
			fimTurno = true;
			numeroJogadas = 0;
		}
		
	}
	

	public void novoTurno(Jogador oponente)
	{
		this.oponente = oponente;
		fimTurno = false;
		notificarObservers();
	}

	public void addObserver(Observer o)
	{
		listaObservers.add(o);
		notificarObservers();
	}

	public void removeObserver(Observer o)
	{
		listaObservers.remove(o);
	}
	
	private void notificarObservers()
	{
		for(Observer o: listaObservers) 
		{
			o.notify(this);
		}
	}


	public Object get() 
	{	
		Object dados[]=new Object[2];
//		
//		dados[0]=matrizTabuleiro;
		dados[1]=fimTurno;
//		dados[2]= Boolean.valueOf(tabuleiroCompleto);
//		dados[3] = Boolean.valueOf(primeiroMovimentoFeito);
//		return dados;
		return dados;
	}

	
}
