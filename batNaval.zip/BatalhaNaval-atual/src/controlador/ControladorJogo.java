package controlador;

import regras.*;

import gui.FRFaseAtaques;

public class ControladorJogo {
	private Jogador jogador1,jogador2;
	private Jogador jogadorAtual,oponente;
	private String faseJogo;
	private ControladorTelas controladorTelas;
	private boolean transicaoTurno;
	
	public ControladorJogo(ControladorTelas controladorTelas,Jogador jogador1,Jogador jogador2,String faseJogo)
	{
		this.jogador1 = jogador1;
		this.jogador2 = jogador2;
		this.faseJogo = faseJogo;
		jogadorAtual = jogador1;
		this.controladorTelas = controladorTelas;
		transicaoTurno = false;
		
	}
	
	public void mudarVezFasePosicionamento(Arma armas[][])
	{
		if (jogadorAtual == jogador1) 
		{
			jogador1.setArmas(armas);
			jogadorAtual = jogador2;
		} 
		else 
		{
			jogador2.setArmas(armas);
			jogadorAtual = jogador1;
			oponente = jogador2;
			faseJogo = "ataque";
			transicaoTurno = true;
			controladorTelas.FaseDeAtaques();
		}
	}
	
	public void mudarVezFaseAtaques()
	{
		
		if(transicaoTurno)
		{
			jogadorAtual = jogador1;
			oponente = jogador2;
			transicaoTurno = false;
		}
			
		else if(!transicaoTurno && jogadorAtual == jogador1)
		{
			jogadorAtual = jogador2;
			oponente = jogador1;
		}
		else if(!transicaoTurno && jogadorAtual == jogador2)
		{
			transicaoTurno = true;

		}

			
	}
	
	public Jogador getJogadorAtual( )
	{
		return jogadorAtual;
	}
	
	public boolean getTransicao()
	{
		return transicaoTurno;
	}
	
	
	public Jogador getOponente() {
		
		return oponente;
	}
	
	



	
	
	
}