package regras;

public class Jogador 
{
	private String nome;
	private Arma[][] matrizArmas;
	private int[][] tirosNaAgua;
	private int numCasasRestantes;
	private int numTirosAgua;
	
	public Jogador(String nome)
	{
		this.nome = nome;
		matrizArmas = new Arma[15][15];
		tirosNaAgua = new int [225][2];
		numCasasRestantes = 4;
		numTirosAgua = 0;
	}
	public void setArmas(Arma armas[][])
	{
		for (int i = 0; i < 15; i++)
			for (int j = 0; j < 15; j++)
				matrizArmas[i][j] = armas[i][j];
	}
	public Arma[][] getMatrizArmas( )
	{
		return matrizArmas;
	}
	public String getNome()
	{
		return nome;
	}
	
	
	
	
	
	public boolean verificarTiroAgua(int i,int j) 
	{
		for(int contador=0;contador<numTirosAgua;contador++)
		{
			if(tirosNaAgua[contador][0] == i && tirosNaAgua[contador][1] == j)
				return true;
		}
		return false;

	}

	public boolean adicionarTiroAgua(int i, int j)
	{
		boolean existeTiroNaAgua = verificarTiroAgua(i,j);
		if(!existeTiroNaAgua)
		{
			tirosNaAgua[numTirosAgua][0] = i;
			tirosNaAgua[numTirosAgua][1] = j;
			numTirosAgua++;
			return true;
		}
		return false;
	}
	
	public boolean diminuirCasasRestantes()
	{
		numCasasRestantes--;
		return numCasasRestantes == 0;
	}
		
	
}
