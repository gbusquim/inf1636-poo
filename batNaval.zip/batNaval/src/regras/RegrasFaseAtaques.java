package regras;

import java.util.ArrayList;
import java.util.List;

public class RegrasFaseAtaques implements Observable {
	Jogador oponente;
	private List<Observer> listaObservers = new ArrayList<Observer>();
	private int numeroJogadas = 0;
	private boolean fimTurno;
	private String mensagem;
	private boolean fimJogo;
	
	
	
	
	public RegrasFaseAtaques(Jogador oponente)
	{
		this.oponente = oponente;
		numeroJogadas = 0;
		fimTurno = false;
		fimJogo = false;
	}
	
	
	
	public void verificarCasaSelecionada(int i,int j)
	{
		if (!fimTurno)
		{
			Arma armaSelecionada = oponente.getMatrizArmas()[i][j];
			boolean jogadaValida = false;
			if(armaSelecionada == null)
			{
				jogadaValida = oponente.adicionarTiroAgua(i,j);
				if(jogadaValida)
				{
					mensagem = "Voc� acertou um tiro na �gua";
					System.out.println("grr");
					notificarObservers();
					aumentarNumeroJogadas();
				}
			}
			else
			{
				if(!armaSelecionada.foiDestruida())
				{
					jogadaValida = armaSelecionada.adicionarCasaDestruida(i, j);
					if(jogadaValida)
					{
						String tipoArma = armaSelecionada.getTipo();
						if(armaSelecionada.foiDestruida())
							mensagem = "Voc� destruiu um "+ tipoArma;
						else
							mensagem = "Voc� destruiu parte de um "+ tipoArma;
						fimJogo = oponente.diminuirCasasRestantes();
						notificarObservers();
						aumentarNumeroJogadas();
					}
				}
			}
		}
	}
	
	
	
	public void aumentarNumeroJogadas() {
		numeroJogadas++;
		if(numeroJogadas == 3)
		{
			fimTurno = true;
			notificarObservers();
			
		}
		
	}
	
	public void travarTurno()
	{
		fimTurno = true;
		notificarObservers();
	}
	
	
	public void novoTurno(Jogador oponente)
	{
		fimTurno = false;
		this.oponente = oponente;
		numeroJogadas = 0;
		mensagem="Clique em uma casa do oponente!";
		notificarObservers();
	}

	public void addObserver(Observer o)
	{
		listaObservers.add(o);
	}

	public void removeObserver(Observer o)
	{
		listaObservers.remove(o);
	}
	
	private void notificarObservers()
	{
		for(Observer o: listaObservers) 
		{
			o.notify(this);
		}
	}


	public Object get() 
	{	
		Object dados[]=new Object[4];	
		dados[0]=oponente;
		dados[1] = String.valueOf(mensagem);
		dados[2]=Boolean.valueOf(fimTurno);
		dados[3]= Boolean.valueOf(fimJogo);
		

		return dados;
	}

	
}
