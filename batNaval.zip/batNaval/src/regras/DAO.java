package regras;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.JFileChooser;

import controlador.ControladorJogo;

public class DAO 
{
		private static DAO acessoArquivos = null;
		
		private DAO() 
		{
			
		}
		
		public static DAO getDAO() 
		{
			if (acessoArquivos == null) 
			{
				acessoArquivos = new DAO();
			}
			return acessoArquivos;
		}
		
		public void salvarJogo() 
		{
			
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
			int resultado = fileChooser.showSaveDialog(null);
	        if (resultado == JFileChooser.APPROVE_OPTION) 
	        {
				try
				{
					FileWriter fileWriter = new FileWriter(fileChooser.getSelectedFile() +".txt");
					fileWriter.write("TotalJogadores\n");
	//			fileWriter.write("\n");
	//			Player p = board.getCurrentPlayer();
	//			int currentPlayer = p.getNumber();
	//			
	//			for (int i = 0; i < playersCount; i++) {
	//                currentPlayer += 1;
	//    			currentPlayer = currentPlayer % board.getPlayers().size();
	//                Player player = board.getPlayers().get(currentPlayer);
	//                int cardsCount = player.getCards().size();
	//                int businessesCount = player.getBusinesses().size();
	//                
	//                fileWriter.write(player.getName() + "\n"); // name
	//                fileWriter.write("Posicao " + player.getPosition() + "\n"); // position
	//                fileWriter.write("Capital " + player.getWealth() + "\n"); // wealth
	//                fileWriter.write("Preso " + player.getIsArrested() + "\n"); // wealth
	//                fileWriter.write("TotalCartas " + cardsCount + "\n");
	//                
	//                for (int j = 0; j < cardsCount; j++) {
	//                	fileWriter.write(player.getCards().get(j).getName() + " ");
	//                }
	//                
	//                fileWriter.write("\n");
	//                fileWriter.write("TotalLote " + businessesCount + "\n");
	//                
	//                for (int j = 0; j < businessesCount; j++) {
	//                	fileWriter.write(player.getBusinesses().get(j).getCardTypeName() + " ");
	//                	if (player.getBusinesses().get(j) instanceof Property) {
	//                		fileWriter.write(((Property) player.getBusinesses().get(j)).getConstructions() + " ");
	//                	} else {
	//                		fileWriter.write("0 ");
	//                	}
	//                	
	//                }
	//               
	//                fileWriter.write("\n");
	//                fileWriter.write("\n");
	//            }
	//            
					fileWriter.close();
				} 
				catch (FileNotFoundException e) 
				{
					e.printStackTrace();
				} 
				catch (IOException e) 
				{
					e.printStackTrace();
				}
		    }
		}
		
		public ControladorJogo open() throws Exception {
			JFileChooser fileChooser = new JFileChooser();
			fileChooser.setCurrentDirectory(new File("jogosSalvos/"));
			int resultado = fileChooser.showOpenDialog(null);
//			String data[], name;
//			int playersCount, number, position, cardsCount, businessesCount;
//			boolean isArrested;
//			float wealth;
//			ArrayList<Player> players = new ArrayList<Player>();
//			ArrayList<Lot> lots = instance.createAllLots();
//			LinkedList<Card> allCards = instance.createAllCards();
			
			if (resultado == JFileChooser.APPROVE_OPTION) {
			    File arquivoEscolhido = fileChooser.getSelectedFile();

			    try {
		            Scanner sc = new Scanner(arquivoEscolhido);
		           
		            data = sc.nextLine().split("\\s+");
		            playersCount = Integer.parseInt(data[1]);
	 
		            for (int i = 0; i < playersCount; i++) {
		            	List<Card> cards = new ArrayList<Card>();
		        		List<Business> businesses = new ArrayList<Business>();
		        		
		            	sc.nextLine();

		                // get name, number
		                data = sc.nextLine().split("\\s+");
		                name = data[0] + " " + data[1];
		                number = Integer.parseInt(data[1]) - 1;

		                // get position
		                data = sc.nextLine().split("\\s+");
		                position = Integer.parseInt(data[1]);

		                // get wealth
		                data = sc.nextLine().split("\\s+");
		                wealth = Float.parseFloat(data[1]);

		                // get isArrested
		                data = sc.nextLine().split("\\s+");
		                isArrested =  Boolean.parseBoolean(data[1]);

		                data = sc.nextLine().split("\\s+");
		                cardsCount = Integer.parseInt(data[1]);

		                Player player = new Player(number, name, position, wealth, isArrested, cards, businesses);

		                data = sc.nextLine().split("\\s+");
		                for (int j = 0; j < cardsCount; j++) {
		                	for (Card c : allCards) {
	                			if (data[j].equals(c.getName())) {
	                				allCards.remove(j);
	                				cards.add(c);
	                				break;
		                        }
		                    }
		                }
		                
		                data = sc.nextLine().split("\\s+");
		                businessesCount = Integer.parseInt(data[1]);
		                businessesCount *= 2;
		                data = sc.nextLine().split("\\s+");
		                for (int j = 0; j < businessesCount; j+=2) {
		                	for (Lot l : lots) {
		                		if (l instanceof Business) {
		                			if (data[j].equals(((Business) l).getCardTypeName())) {
		                				businesses.add((Business) l);
		                				if (l instanceof Property) {
		                					((Property) l).buyConstruction(Integer.parseInt(data[j + 1]));
		                				}
		                				((Business) l).changeOwner(player);
			                            break;
			                        }
		                		}
		                    }
		                }
		                player.addCards(cards);
		                player.addBusiness(businesses);
		                players.add(player);
		            }
		            
		            board = new Board(players, lots, allCards);
		            board.setLastCard(allCards.getFirst());
		            sc.close();
		        } catch (IOException e) {
		            System.out.println(e);
		        } catch (NumberFormatException e) {
		        	System.out.println(e);
		        }
			} else if (result == JFileChooser.CANCEL_OPTION) {
				Exception e = new Exception();
	            System.out.println(e);
				throw e;
			}
			return board;
		}
		
		
	}
